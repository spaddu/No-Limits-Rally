import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import { Input } from './input.js';
import { Menu } from './menu.js';
import { RaceSession } from './session.js';
import { TRACKS } from './tracks.js';
import { CARS } from './cars.js';

const loadingEl = document.getElementById('loading');
const speedEl = document.getElementById('speed-value');

function showError(err) {
  console.error(err);
  loadingEl.classList.add('error');
  loadingEl.style.display = 'grid';
  loadingEl.textContent = 'Game error:\n' + (err?.message ?? err);
}
addEventListener('error', (e) => showError(e.error ?? e.message));
addEventListener('unhandledrejection', (e) => showError(e.reason));

await RAPIER.init();

// --- Renderöinti -------------------------------------------------------------
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));   // tarkat näytöt: enintään 1,5 × (2 × = 4 × pikseleitä)
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
document.body.appendChild(renderer.domElement);

const input = new Input();
let session = null;

/** Purkaa vanhan session ja rakentaa uuden (rata + auto). */
function buildSession(trackIdx, carIdx) {
  session?.dispose();
  session = null;
  session = new RaceSession(RAPIER, TRACKS[trackIdx], CARS[carIdx]);
  session.choice = { track: trackIdx, car: carIdx };
}

const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));

const menu = new Menu({
  async onStart(trackIdx, carIdx) {
    const c = session?.choice;
    if (!c || c.track !== trackIdx || c.car !== carIdx) {
      // Näytetään latausteksti ennen raskasta rakennusta
      loadingEl.textContent = `Loading ${TRACKS[trackIdx].name}…`;
      loadingEl.style.display = 'grid';
      await nextFrame();
      await nextFrame();
      buildSession(trackIdx, carIdx);
      loadingEl.style.display = 'none';
    } else {
      session.restart();
    }
    closeMenu();
  },
  onResume() {
    closeMenu();
  },
});

function openMenu() {
  if (session.mapView.active) session.mapView.toggle();
  menu.open({ current: session.choice, canResume: session.driven });
}

function closeMenu() {
  menu.close();
  input.clearEvents();
  last = performance.now();
}

// Ensimmäinen näkymä: viimeksi valittu rata ja auto valikon taustalla
buildSession(menu.track, menu.car);
menu.open();
loadingEl.style.display = 'none';

// --- Pelisilmukka -------------------------------------------------------------
let last = performance.now();

renderer.setAnimationLoop((now) => {
  const dt = Math.min((now - last) / 1000, 0.1);
  last = now;
  if (!session) return;

  if (menu.isOpen) {
    input.clearEvents();
    session.idle(dt);
  } else {
    if (input.consumeMenu()) openMenu();
    else session.drive(dt, input);
  }

  speedEl.textContent = Math.round(Math.abs(session.car.speed) * 3.6);
  session.render(renderer);
});

addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight);
  session?.resize();
});

// Kehitystä ja testausta varten selaimen konsolista: window.game
window.game = {
  THREE, RAPIER, renderer, input, menu,
  get session() { return session; },
  get car() { return session.car; },
  get road() { return session.road; },
  get stage() { return session.stage; },
};
