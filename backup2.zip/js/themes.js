// =============================================================================
//  TEEMAT – ratojen ympäristöt
// =============================================================================
//  Teema määrää taivaan, valaistuksen, maaston värit, tien pinnan, pölyn värit
//  ja maisemaelementit. Rata valitsee teemansa tracks.js:ssä (theme: '…').
// =============================================================================

import * as THREE from 'three';
import { createNoise2D, smoothstep } from './noise.js';
import { createScenery } from './scenery.js';
import { planFinland, finlandOverlay, buildFinland, farmsteadPads } from './sceneryFinland.js';
import { planTuscany, tuscanyColorFn, buildTuscany } from './sceneryTuscany.js';
import { planDesert, desertColorFn, buildDesert } from './sceneryDesert.js';

/** Suomalaisen metsän maaston väritys (Harjun kierre alkuperäisenä); layout = hakkuuaukeat ja pellot. */
function forestColorFn(layout) {
  const overlay = layout ? finlandOverlay(layout) : null;
  const patchNoise = createNoise2D(2024);
  const cLush = new THREE.Color('#4f8f37');
  const cGrassA = new THREE.Color('#78b04a');
  const cGrassB = new THREE.Color('#5e9d3d');
  const cDry = new THREE.Color('#a9b65c');
  const cWorn = new THREE.Color('#93a35a');    // kulunut ruoho tien vieressä
  const cVerge = new THREE.Color('#9c8a6c');   // sorainen piennar
  const cDirt = new THREE.Color('#8f7556');
  const cRock = new THREE.Color('#9a968f');
  const cSnow = new THREE.Color('#eef3f5');
  return (col, t) => {
    const patch = patchNoise(t.x * 0.02, t.z * 0.02) * 0.5 + 0.5;
    col.copy(cGrassA).lerp(cGrassB, patch);
    col.lerp(cLush, smoothstep(-2, -9, t.h) * 0.8);
    col.lerp(cDry, smoothstep(8, 16, t.h) * 0.7);
    col.lerp(cDirt, smoothstep(0.9, 0.78, t.slope));
    col.lerp(cRock, smoothstep(0.78, 0.62, t.slope));
    col.lerp(cSnow, smoothstep(30, 40, t.h) * smoothstep(0.45, 0.7, t.slope));
    if (overlay) overlay(col, t);
    col.lerp(cWorn, smoothstep(t.flat + 5, t.flat + 1, t.rd) * 0.7);
    col.lerp(cVerge, smoothstep(t.flat + 0.8, t.flat - 0.4, t.rd));
    col.multiplyScalar(0.93 + t.rand() * 0.12);
  };
}

export const THEMES = {
  // --- Suomalainen metsä (Harjun kierre, Päijälä, Ouninpohja) -------------------
  forest: {
    sky: '#9fd3ee',
    fog: [130, 420],
    hemi: ['#d6ecff', '#55663a', 1.3],
    sun: ['#fff4e0', 2.4],
    road: null,     // = roadMesh.js:n oletussora
    dust: null,     // = dust.js:n oletuspaletti
    plan: planFinland,
    pads: farmsteadPads,       // pihapiirien tasanteet (scenery.farmsteads)
    terrainColor: (layout) => forestColorFn(layout),
    build: (ctx) => {
      const { scene, world, RAPIER, terrain, road, options, layout } = ctx;
      // legacyDistance: puut sijoitellaan alkuperäisen lähikentän mukaan (Harjun kierre pysyy ennallaan)
      const t = options.legacyDistance ? { ...terrain, roadDistanceAt: terrain.roadDistanceNearAt } : terrain;
      createScenery(scene, world, RAPIER, t, road, options, layout);
      buildFinland(ctx);
    },
  },

  // --- Italian kukkulat (Torrevecchia) -----------------------------------------
  tuscany: {
    sky: '#a6d2ef',
    fog: [150, 440],
    hemi: ['#e6f1ff', '#7d7448', 1.25],
    sun: ['#fff0d0', 2.8],
    // Strada bianca: vaalea kalkkikivisora
    road: ['#e3dccb', '#c6bba4', '#dcd4c0', '#d2cbb0', '#dcd4c0', '#c6bba4', '#e3dccb'],
    dust: {
      road: ['#f2ede2', '#e9e2d2', '#f7f3ea'],
      offroad: ['#d3c69e', '#c8ba90', '#dacfab'],
      roadBits: ['#d2c9b4', '#bcb09a', '#e2dbcb'],
      offroadBits: ['#93a44c', '#a99d5c', '#7d6c4b'],
    },
    plan: planTuscany,
    terrainColor: (layout) => tuscanyColorFn(layout),
    build: buildTuscany,
  },

  // --- Egyptin aavikko (Bawiti) --------------------------------------------------
  desert: {
    sky: '#c7dfea',
    fog: [160, 470],
    hemi: ['#fff6e4', '#b8925a', 1.35],
    sun: ['#fff2d6', 3.0],
    // Tiivistynyt hiekkatie
    road: ['#dbbd88', '#b9955f', '#d4b27d', '#cbaa76', '#d4b27d', '#b9955f', '#dbbd88'],
    dust: {
      road: ['#efdcb3', '#e6cf9f', '#f4e6c8'],
      offroad: ['#f0daa9', '#e9d099', '#f5e4be'],
      roadBits: ['#c9a46a', '#b8935a', '#d8b880'],
      offroadBits: ['#d9b77a', '#c8a265', '#e2c590'],
    },
    plan: planDesert,
    terrainColor: (layout) => desertColorFn(layout),
    build: buildDesert,
  },
};
