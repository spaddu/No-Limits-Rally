// =============================================================================
//  AUTOT – valikossa näkyvät autot
// =============================================================================
//  Jokaisella autolla on config-kohdassa kaikki ajosäädöt. Tärkeimmät erot:
//    driveFront  vetävien renkaiden jako: 1 = etuveto, 0 = takaveto, 0.4 = neliveto
//    engineForce moottorin voima (keskimäärin per rengas)
//    mass        massa (kg)
//    friction*   renkaiden pito
//    tractionControl luistonesto 0…1 (car.js)
//  model = placeholder-mallin tyyli ('hatch', 'retro', 'wrc') ja väri.
//  stats = valikon palkit (0–5), puhtaasti näyttöä varten.
// =============================================================================

export const CARS = [
  {
    id: 'etuveto',
    name: 'FWD Hatchback',
    drive: 'Front-wheel drive',
    description: 'Light and grippy, easy to drive, but the least power',
    color: '#2f6fdf',
    model: { style: 'hatch', color: '#2f6fdf' },
    stats: { power: 2, grip: 5, agility: 4 },
    config: {
        mass: 1000,
        centerOfMassY: -0.7,          // epärealistisen matala painopiste = auto ei kaadu helposti
        chassisHalf: { x: 1.9, y: 0.25, z: 0.8 },

        wheelRadius: 0.42,
        wheelWidth: 0.34,
        wheelX: 1.25,                 // akselien etäisyys keskeltä
        wheelZ: 0.86,                 // renkaiden etäisyys keskeltä sivulle
        wheelY: -0.25,                // jousituksen kiinnityskohta

        suspensionRest: 0.45,         // jousen lepopituus
        suspensionTravel: 0.3,        // suurin joustomatka
        suspensionStiffness: 30,
        suspensionCompression: 3.2,   // vaimennus puristuessa (pienempi = pomppivampi)
        suspensionRelaxation: 3.6,    // vaimennus palautuessa
        maxSuspensionForce: 100000,

        frictionFront: 1.15,
        frictionRear: 1.2,
        frictionHandbrake: 0.4,

        driveFront: 1.0,              // vetävien renkaiden jako: 1 = etuveto, 0 = takaveto
        tractionControl: 0,           // luistonesto 0…1 (0 = pois, 1 = puolet pidosta varataan ohjaukselle)
        engineForce: 3000,            // keskimäärin per rengas (koko voima = 4 ×)
        reverseForce: 2200,
        maxSpeed: 25,                 // m/s (~115 km/h)
        maxReverseSpeed: 8,

        brake: 50,
        coastBrake: 1.2,              // hidastuu itsestään kun kaasu ei ole pohjassa
        holdBrake: 40,                // pitää auton paikallaan rinteessä
        handbrake: 60,

        maxSteer: 0.5,               // rad paikallaan
        minSteer: 0.1,                // rad vähintään
        steerFalloff: 12,             // m/s; kääntökulma puolittuu tällä nopeudella
        steerSpeed: 10,

        airLevel: 4000,               // Nm, ilmassa auto oikaisee itseään
        airLevelDamping: 1200,
        airYaw: 1500,                 // Nm, ilmassa A/D kääntää autoa

        // Alusta: soratiellä käytetään yllä olevia pitoarvoja, maastossa näitä kertoimia
        offroadGrip: 0.85,            // pidon kerroin tien ulkopuolella
        offroadDrag: 0.12,            // vierintävastus tien ulkopuolella (1/s): hidastaa ja laskee huippunopeutta
    },
  },
  {
    id: 'takaveto',
    name: 'Retro RWD',
    drive: 'Rear-wheel drive',
    description: 'A wild and powerful 80s beast with a lively rear end',
    color: '#e8b81c',
    model: { style: 'retro', color: '#e8b81c', stripe: '#1e1e22' },
    stats: { power: 5, grip: 2, agility: 3 },
    config: {
        mass: 1100,
        centerOfMassY: -0.7,          // epärealistisen matala painopiste = auto ei kaadu helposti
        chassisHalf: { x: 1.9, y: 0.25, z: 0.8 },

        wheelRadius: 0.42,
        wheelWidth: 0.34,
        wheelX: 1.25,                 // akselien etäisyys keskeltä
        wheelZ: 0.86,                 // renkaiden etäisyys keskeltä sivulle
        wheelY: -0.25,                // jousituksen kiinnityskohta

        suspensionRest: 0.45,         // jousen lepopituus
        suspensionTravel: 0.3,        // suurin joustomatka
        suspensionStiffness: 30,
        suspensionCompression: 3.2,   // vaimennus puristuessa (pienempi = pomppivampi)
        suspensionRelaxation: 3.6,    // vaimennus palautuessa
        maxSuspensionForce: 100000,

        frictionFront: 1.1,
        frictionRear: 1.0,
        frictionHandbrake: 0.35,

        driveFront: 0.0,              // vetävien renkaiden jako: 1 = etuveto, 0 = takaveto
        tractionControl: 0,           // luistonesto 0…1 (0 = pois, 1 = puolet pidosta varataan ohjaukselle)
        engineForce: 5200,            // keskimäärin per rengas (koko voima = 4 ×)
        reverseForce: 3200,
        maxSpeed: 26,                 // m/s (~115 km/h)
        maxReverseSpeed: 8,

        brake: 50,
        coastBrake: 1.2,              // hidastuu itsestään kun kaasu ei ole pohjassa
        holdBrake: 40,                // pitää auton paikallaan rinteessä
        handbrake: 60,

        maxSteer: 0.6,               // rad paikallaan
        minSteer: 0.1,                // rad vähintään
        steerFalloff: 15,             // m/s; kääntökulma puolittuu tällä nopeudella
        steerSpeed: 11,

        airLevel: 4000,               // Nm, ilmassa auto oikaisee itseään
        airLevelDamping: 1200,
        airYaw: 1500,                 // Nm, ilmassa A/D kääntää autoa

        // Alusta: soratiellä käytetään yllä olevia pitoarvoja, maastossa näitä kertoimia
        offroadGrip: 0.85,            // pidon kerroin tien ulkopuolella
        offroadDrag: 0.12,            // vierintävastus tien ulkopuolella (1/s): hidastaa ja laskee huippunopeutta
    },
  },
  {
    id: 'wrc',
    name: 'WRC AWD',
    drive: 'All-wheel drive',
    description: 'Modern rally weapon: strong acceleration and controllable slides',
    color: '#d8342c',
    model: { style: 'wrc', color: '#d8342c' },
    stats: { power: 4, grip: 3, agility: 5 },
    config: {
        mass: 1300,
        centerOfMassY: -0.7,          // epärealistisen matala painopiste = auto ei kaadu helposti
        chassisHalf: { x: 1.9, y: 0.25, z: 0.8 },

        wheelRadius: 0.42,
        wheelWidth: 0.34,
        wheelX: 1.25,                 // akselien etäisyys keskeltä
        wheelZ: 0.86,                 // renkaiden etäisyys keskeltä sivulle
        wheelY: -0.25,                // jousituksen kiinnityskohta

        suspensionRest: 0.45,         // jousen lepopituus
        suspensionTravel: 0.3,        // suurin joustomatka
        suspensionStiffness: 30,
        suspensionCompression: 3.2,   // vaimennus puristuessa (pienempi = pomppivampi)
        suspensionRelaxation: 3.6,    // vaimennus palautuessa
        maxSuspensionForce: 100000,

        frictionFront: 1.05,
        frictionRear: 1.0,
        frictionHandbrake: 0.4,

        driveFront: 0.4,              // vetävien renkaiden jako: 1 = etuveto, 0 = takaveto
        tractionControl: 0.0,           // luistonesto 0…1 (0 = pois, 1 = puolet pidosta varataan ohjaukselle)
        engineForce: 4600,            // keskimäärin per rengas (koko voima = 4 ×)
        reverseForce: 3200,
        maxSpeed: 30,                 // m/s (~115 km/h)
        maxReverseSpeed: 12,

        brake: 50,
        coastBrake: 1.2,              // hidastuu itsestään kun kaasu ei ole pohjassa
        holdBrake: 40,                // pitää auton paikallaan rinteessä
        handbrake: 60,

        maxSteer: 1.1,               // rad paikallaan
        minSteer: 0.1,                // rad vähintään
        steerFalloff: 15,             // m/s; kääntökulma puolittuu tällä nopeudella
        steerSpeed: 11,

        airLevel: 4000,               // Nm, ilmassa auto oikaisee itseään
        airLevelDamping: 1200,
        airYaw: 1500,                 // Nm, ilmassa A/D kääntää autoa

        // Alusta: soratiellä käytetään yllä olevia pitoarvoja, maastossa näitä kertoimia
        offroadGrip: 0.85,            // pidon kerroin tien ulkopuolella
        offroadDrag: 0.12,            // vierintävastus tien ulkopuolella (1/s): hidastaa ja laskee huippunopeutta
    },
  },
];
