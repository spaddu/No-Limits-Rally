// Maaston korkeusdata ilman grafiikkaa: luonnollinen maasto kohinasta,
// johon tie "rakennetaan" leikkauksineen ja penkereineen.
// Tiedosto ei riipu Three.js:stä, joten sitä voi ajaa myös Nodella.

import { createNoise2D, fbm, smoothstep } from './noise.js';

export const TERRAIN_SIZE = 640;   // oletuskoko: metriä sivulla (radat voivat muuttaa: terrain.size)
export const CELL = 1.6;           // tarkimman ruudun koko (m)
export const CHUNK = 20;           // tarkkuuspalan koko ruutuina (32 m)
export const RENDER_CHUNK = 2;     // piirrettävä pala = 2 × 2 tarkkuuspalaa (64 m)

/**
 * Maaston tarkkuus palan etäisyyden mukaan tiestä: [etäisyys alle (m), ruutuaskel].
 * Askel 1 = 1,6 m ruudut, 2 = 3,2 m, 4 = 6,4 m. Kaukana tiestä maasto on harvempaa.
 * Tien muotoilu ulottuu n. 14 m päähän, joten sen kohdalla maasto on aina tarkinta.
 */
export const LOD_LEVELS = [[16, 1], [50, 2], [Infinity, 4]];

/** Maastoruudukko annetulle koolle: size (m), half, segments (ruutuja sivulla), cell, n (pisteitä sivulla). */
export function makeGrid(size = TERRAIN_SIZE) {
  const unit = CHUNK * RENDER_CHUNK;
  const segments = Math.max(1, Math.round(size / CELL / unit)) * unit;
  return { size, half: size / 2, segments, cell: size / segments, n: segments + 1 };
}

/**
 * Maaston oletusasetukset. Radat voivat muuttaa näitä (tracks.js):
 * seed vaihtaa koko maaston muodon, muut säätävät mäkien kokoa.
 */
export const DEFAULT_TERRAIN = {
  seed: null,         // null = rata 1:n alkuperäinen maasto, numero = uusi maasto
  size: TERRAIN_SIZE, // alueen koko (m); reunavuoret ovat aina reunoilla
  hills: 40,          // isojen mäkien korkeus (m)
  hillScale: 0.0095,  // isojen mäkien tiheys (suurempi = tiheämpiä mäkiä)
  ridges: 14,         // terävien harjanteiden korkeus (m)
  bumps: 2.4,         // pienten kumpareiden korkeus (m)
  rim: 40,            // reunavuorten korkeus (m)
  ridgeScale: [0.013, 0.013], // harjanteiden tiheys x- ja z-suunnassa (eri luvut = venytetyt dyynit)
  basins: [],         // painanteet [x, z, säde, syvyys], esim. keitaat
  plateaus: [],       // tasanteet [x, z, säde, korkeus], esim. kylä tai pyramidit
  lowland: null,      // alanko [dx, dz, siirtymä, leveys, kerroin]: suunnan (dx, dz) puolella maasto madaltuu
};

/** Luo funktion naturalHeight(x, z): luonnollinen maasto ilman tietä. */
export function createNaturalHeight(params = {}) {
  const P = { ...DEFAULT_TERRAIN, ...params };
  const seeds = P.seed == null ? [1337, 9001, 4242, 777] : [P.seed, P.seed * 7 + 1, P.seed * 3 + 2, P.seed + 99];
  const hills = createNoise2D(seeds[0]);
  const ridges = createNoise2D(seeds[1]);
  const bumps = createNoise2D(seeds[2]);
  const rim = createNoise2D(seeds[3]);

  return function naturalHeight(x, z) {
    // Isot mäet ja laaksot
    let h = fbm(hills, x * P.hillScale, z * P.hillScale, 4, 2, 0.5) * P.hills;
    // Terävät harjanteet: kohinan "taitekohdat" nostetaan kapeiksi selänteiksi
    const rr = 1 - Math.abs(ridges(x * P.ridgeScale[0], z * P.ridgeScale[1]));
    h += rr * rr * rr * P.ridges - P.ridges * (5 / 14);
    // Pienemmät kumpareet, joista saa hyppyjä
    h += bumps(x * 0.05, z * 0.05) * P.bumps;

    // Alanko (esim. jokisuisto): toisella puolella maasto tasoittuu kertoimen verran
    if (P.lowland) {
      const [dx, dz, off, width, factor] = P.lowland;
      const t = smoothstep(off - width / 2, off + width / 2, x * dx + z * dz);
      h *= 1 + (factor - 1) * t;
    }

    // Tasanteet: maasto tasoittuu annettuun korkeuteen, reunoilla pehmeä siirtymä
    for (const [px, pz, pr, ph] of P.plateaus) {
      const d = Math.hypot(x - px, z - pz);
      if (d < pr) {
        const t = smoothstep(pr, pr * 0.6, d);
        h += (ph - h) * t;
      }
    }

    // Painanteet (keitaat): maasto laskee loivasti kohti keskustaa
    for (const [bx, bz, br, depth] of P.basins) {
      const d = Math.hypot(x - bx, z - bz);
      if (d < br) {
        const t = 1 - d / br;
        h -= depth * t * t * (3 - 2 * t);
      }
    }

    // Reunoille nousevat vuoret rajaamaan alueen
    const edge = Math.max(Math.abs(x), Math.abs(z)) / (P.size / 2);
    const r = smoothstep(0.8, 1.0, edge);
    h += r * r * (P.rim + rim(x * 0.02, z * 0.02) * 15);

    return h;
  };
}

/**
 * Laskee korkeusruudukon, johon tie on muotoiltu, sekä etäisyyskentän
 * (jokaisen ruudukkopisteen etäisyys tien keskilinjaan).
 */
/**
 * pads = tasanteet tien varren pihoille: [{ x, z, r, falloff, h }]. Maasto tasoittuu
 * korkeuteen h säteellä r ja liittyy luonnolliseen maahan falloff-metrin matkalla.
 * baseHeightAt palauttaa maaston ilman tasanteita (maiseman satunnaissijoittelu pysyy ennallaan).
 */
export function buildHeightfield(road, naturalHeight, pads = [], grid = makeGrid()) {
  const { half: HALF, segments: SEGMENTS, cell: CELL, n: N, size: TERRAIN_SIZE } = grid;
  const heights = new Float32Array(N * N);   // [rivi z][sarake x]
  const roadDist = new Float32Array(N * N).fill(1e6);
  const roadH = new Float32Array(N * N);

  for (let i = 0; i < N; i++) {
    const z = -HALF + i * CELL;
    for (let j = 0; j < N; j++) {
      heights[i * N + j] = naturalHeight(-HALF + j * CELL, z);
    }
  }
  const base = pads.length ? heights.slice() : null;
  for (const p of pads) {
    for (let i = 0; i < N; i++) {
      const z = -HALF + i * CELL;
      if (Math.abs(z - p.z) > p.r + p.falloff) continue;
      for (let j = 0; j < N; j++) {
        const x = -HALF + j * CELL;
        const d = Math.hypot(x - p.x, z - p.z);
        if (d >= p.r + p.falloff) continue;
        const k = i * N + j;
        heights[k] += (p.h - heights[k]) * smoothstep(p.r + p.falloff, p.r, d);
      }
    }
  }

  // --- Etäisyyskenttä: käydään läpi tien janat ja niiden lähiruudut ------
  const flat = road.halfWidth + road.shoulder;  // tasainen osa keskilinjasta
  const reach = flat + road.blend + 2;          // kuinka kauas tie vaikuttaa
  const { xs, zs, hs, count } = road;
  for (let s = 0; s < road.segCount; s++) {
    const s2 = (s + 1) % count;
    const ax = xs[s], az = zs[s], bx = xs[s2], bz = zs[s2];
    const dx = bx - ax, dz = bz - az;
    const len2 = dx * dx + dz * dz || 1e-9;
    const j0 = Math.max(0, Math.floor((Math.min(ax, bx) - reach + HALF) / CELL));
    const j1 = Math.min(N - 1, Math.ceil((Math.max(ax, bx) + reach + HALF) / CELL));
    const i0 = Math.max(0, Math.floor((Math.min(az, bz) - reach + HALF) / CELL));
    const i1 = Math.min(N - 1, Math.ceil((Math.max(az, bz) + reach + HALF) / CELL));
    for (let i = i0; i <= i1; i++) {
      const pz = -HALF + i * CELL;
      for (let j = j0; j <= j1; j++) {
        const px = -HALF + j * CELL;
        let t = ((px - ax) * dx + (pz - az) * dz) / len2;
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const qx = ax + dx * t - px;
        const qz = az + dz * t - pz;
        const d = Math.sqrt(qx * qx + qz * qz);
        const k = i * N + j;
        if (d < roadDist[k]) {
          roadDist[k] = d;
          roadH[k] = hs[s] + (hs[s2] - hs[s]) * t;
        }
      }
    }
  }

  // --- Tie maastoon: tasainen tienpohja ja luiskat luonnolliseen maahan ---
  for (let k = 0; k < N * N; k++) {
    const d = roadDist[k];
    if (d >= reach) continue;
    const t = smoothstep(flat, flat + road.blend, d);
    heights[k] = roadH[k] + (heights[k] - roadH[k]) * t;
    if (base) base[k] = roadH[k] + (base[k] - roadH[k]) * t;
  }

  // --- Tarkkuustasot: jokaiselle 32 m palalle ruutuaskel sen mukaan, kuinka lähellä tie on ---
  const NC = SEGMENTS / CHUNK;               // paloja sivulla
  const steps = new Uint8Array(NC * NC);
  for (let ci = 0; ci < NC; ci++) {
    for (let cj = 0; cj < NC; cj++) {
      const x0 = -HALF + cj * CHUNK * CELL, x1 = x0 + CHUNK * CELL;
      const z0 = -HALF + ci * CHUNK * CELL, z1 = z0 + CHUNK * CELL;
      const rectDist = (x, z) => Math.hypot(Math.max(x0 - x, 0, x - x1), Math.max(z0 - z, 0, z - z1));
      let d = Infinity;
      for (let k = 0; k < count; k += 2) d = Math.min(d, rectDist(xs[k], zs[k]));
      for (const p of pads) d = Math.min(d, Math.max(0, rectDist(p.x, p.z) - p.r - p.falloff));
      steps[ci * NC + cj] = LOD_LEVELS.find(([lim]) => d < lim)[1];
    }
  }
  // Saumat: tarkemman palan reunapisteet asetetaan harvemman naapurin reunaviivalle (ei rakoja)
  const stepAt = (ci, cj) => (ci < 0 || cj < 0 || ci >= NC || cj >= NC ? 0 : steps[ci * NC + cj]);
  const snapEdge = (arr, i0, j0, di, dj, sn) => {
    for (let t = 0; t <= CHUNK; t++) {
      const r = t % sn;
      if (!r) continue;
      const a = arr[(i0 + di * (t - r)) * N + j0 + dj * (t - r)];
      const b = arr[(i0 + di * (t - r + sn)) * N + j0 + dj * (t - r + sn)];
      arr[(i0 + di * t) * N + j0 + dj * t] = a + (b - a) * (r / sn);
    }
  };
  for (let ci = 0; ci < NC; ci++) {
    for (let cj = 0; cj < NC; cj++) {
      const st = steps[ci * NC + cj];
      const i0 = ci * CHUNK, j0 = cj * CHUNK;
      for (const [ni, nj, ei, ej, di, dj] of [
        [ci - 1, cj, i0, j0, 0, 1], [ci + 1, cj, i0 + CHUNK, j0, 0, 1],
        [ci, cj - 1, i0, j0, 1, 0], [ci, cj + 1, i0, j0 + CHUNK, 1, 0],
      ]) {
        const sn = stepAt(ni, nj);
        if (sn > st) for (const arr of base ? [heights, base] : [heights]) snapEdge(arr, ei, ej, di, dj, sn);
      }
    }
  }

  /** Korkeus samalla kolmiojaolla ja tarkkuudella kuin maastomesh, joten se vastaa pintaa tarkasti. */
  const sample = (arr, x, z) => {
    const gx = Math.min(Math.max((x + HALF) / CELL, 0), SEGMENTS - 1e-4);
    const gz = Math.min(Math.max((z + HALF) / CELL, 0), SEGMENTS - 1e-4);
    const st = steps[Math.floor(gz / CHUNK) * NC + Math.floor(gx / CHUNK)];
    const j = Math.floor(gx / st) * st;
    const i = Math.floor(gz / st) * st;
    const u = (gx - j) / st;
    const v = (gz - i) / st;
    const a00 = arr[i * N + j];
    const a10 = arr[i * N + j + st];
    const a01 = arr[(i + st) * N + j];
    const a11 = arr[(i + st) * N + j + st];
    if (u + v <= 1) return a00 + (a10 - a00) * u + (a01 - a00) * v;
    return a11 + (a01 - a11) * (1 - u) + (a10 - a11) * (1 - v);
  };
  /** Tarkka ruudukko ilman tarkkuustasoja (etäisyyskenttä). */
  const sampleFine = (arr, x, z) => {
    const gx = Math.min(Math.max((x + HALF) / CELL, 0), SEGMENTS - 1e-4);
    const gz = Math.min(Math.max((z + HALF) / CELL, 0), SEGMENTS - 1e-4);
    const j = Math.floor(gx);
    const i = Math.floor(gz);
    const u = gx - j;
    const v = gz - i;
    const a00 = arr[i * N + j];
    const a10 = arr[i * N + j + 1];
    const a01 = arr[(i + 1) * N + j];
    const a11 = arr[(i + 1) * N + j + 1];
    // Sama kolmiojako kuin maastomeshissä, joten korkeus vastaa pintaa tarkasti
    if (u + v <= 1) return a00 + (a10 - a00) * u + (a01 - a00) * v;
    return a11 + (a01 - a11) * (1 - u) + (a10 - a11) * (1 - v);
  };

  // --- Karkea etäisyyskenttä koko alueelle (8 m ruudut) maiseman sijoittelua varten
  const CC = 8;
  const CN = Math.round(TERRAIN_SIZE / CC) + 1;
  const coarse = new Float32Array(CN * CN);
  for (let i = 0; i < CN; i++) {
    const z = -HALF + i * CC;
    for (let j = 0; j < CN; j++) {
      const x = -HALF + j * CC;
      let best = Infinity;
      for (let s = 0; s < count; s += 2) {
        const d = (xs[s] - x) ** 2 + (zs[s] - z) ** 2;
        if (d < best) best = d;
      }
      coarse[i * CN + j] = Math.sqrt(best);
    }
  }
  const coarseAt = (x, z) => {
    const gx = Math.min(Math.max((x + HALF) / CC, 0), CN - 1.0001);
    const gz = Math.min(Math.max((z + HALF) / CC, 0), CN - 1.0001);
    const j = Math.floor(gx), i = Math.floor(gz);
    const u = gx - j, v = gz - i;
    const a = coarse[i * CN + j], b = coarse[i * CN + j + 1];
    const c = coarse[(i + 1) * CN + j], d = coarse[(i + 1) * CN + j + 1];
    return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
  };

  return {
    grid,
    lod: { chunk: CHUNK, count: NC, steps },
    heights,
    roadDist,
    /** Maaston korkeus kohdassa (x, z). */
    heightAt: (x, z) => sample(heights, x, z),
    /** Korkeus ilman pihojen tasanteita. */
    baseHeightAt: (x, z) => sample(base ?? heights, x, z),
    /** Vain tien lähikenttä (kaukana suuri luku); Harjun metsä on sijoiteltu tämän mukaan. */
    roadDistanceNearAt: (x, z) => sampleFine(roadDist, x, z),
    /** Etäisyys tien keskilinjaan (m). Tien lähellä tarkka, kauempana karkea arvio. */
    roadDistanceAt: (x, z) => {
      const d = sampleFine(roadDist, x, z);
      return d < reach - 1 ? d : Math.max(coarseAt(x, z), reach - 1);
    },
  };
}
