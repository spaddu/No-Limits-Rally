# No Limits Rally

Pieni 3D-rallipeli: valitse rata ja auto valikosta ja aja pätkä
mäkien ja metsien keskellä mahdollisimman nopeasti.

## Käynnistys

Tarvitset Node.js:n. Asenna riippuvuudet kerran projektikansiossa:

```
npm install
```

Kehitys (lähdekoodi suoraan selaimeen, kirjastot CDN:stä):

```
npm run dev
```

Avaa sitten selaimessa http://localhost:3000.

## Rakennus palvelimelle (dist)

```
npm run build     kertarakennus
npm run watch     rakentaa, käynnistää palvelimen ja rakentaa uudelleen aina kun
                  tiedosto muuttuu (sama kuin start-js.bat)
npm run preview   kokeile valmista dist-kansiota osoitteessa http://localhost:3000
```

`build.mjs` ajaa esbuildin, joka lähtee `js/main.js`:stä ja seuraa import-lauseita.
Kaikki pelin tiedostot sekä Three.js ja Rapier (node_modules-kansiosta) päätyvät
yhteen minifioituun tiedostoon. Tulos:

- `dist/index.html` (ilman importmapia)
- `dist/style.css`
- `dist/main.min.js` ja `main.min.js.map` (lähdekartta selaimen debuggausta varten,
  palvelimelle ei ole pakko viedä)

Seurantatilassa peli aukeaa osoitteesta http://localhost:3000 (tai seuraavasta
vapaasta portista, jos 3000 on jo käytössä) ja sivu päivittyy itsestään, kun
js-koodi muuttuu. css- ja html-muutosten jälkeen päivitä sivu itse.

Palvelimelle kopioidaan dist-kansion sisältö. Kirjastojen versiot ovat
`package.json`:ssa; jos vaihdat versiota, vaihda se myös `index.html`:n importmapiin.

## Ohjaus

Pelin tekstit ovat englanniksi. Ohjeet näkyvät myös päävalikon alareunassa.

| Näppäin | Toiminto |
|---|---|
| W / ↑ | Kaasu |
| S / ↓ | Jarru, pysähtyneenä peruutus |
| A / D tai ← / → | Ohjaus (ilmassa: auton kääntö) |
| Välilyönti | Käsijarru |
| R | Nosta auto pystyyn |
| T | Takaisin tielle (lähimpään kohtaan) |
| M | Kartta (näyttää reitin ja reittipisteiden numerot) |
| Enter | Uusi yritys (auto lähtöviivalle, ajanotto nollaan) |
| Esc | Valikko (ajo pysähtyy, Esc uudelleen jatkaa) |

## Valikko, radat ja autot

Valikko on kaksiosainen: ensin valitaan rata (maittain ryhmiteltynä) ja sitten
auto. Nuolinäppäimet tai WASD valitsevat, Enter siirtyy seuraavaan vaiheeseen ja
autovaiheessa käynnistää ajon. Esc palaa autovalinnasta ratavalintaan ja
ratavalinnasta takaisin ajoon. Ratakortissa näkyy pätkän pituus ja paras aika
millä tahansa autolla; autokortissa paras aika valitulla radalla.

**Finland** (teema `forest`)
1. **Harju** (2,0 km): mäkinen metsäpätkä isoine nousuineen; noin 520 m kohdalla
   pihapiiri (kaksi vanhaa puutaloa, koivut ja maitolaituri tien vieressä)
2. **Päijälä** (1,8 km): tiheä metsä, lyhyet jyrkät mäet, tiukat mutkat ja hakkuuaukeat
3. **Ouninpohja** (3,8 km): pisin pätkä; metsää, nopeita suoria, tiukkoja mutkia
   ja peltoaukeita punaisine taloineen ja paaleineen. Maasto on muita suurempi
   (960 m, `terrain.size` tracks.js:ssä), joten rata on muita raskaampi piirtää

**Italy** (teema `tuscany`)
1. **Torrevecchia** (1,7 km): pitkä nousu kukkuloiden halki, viinitarhat, maatalot ja
   vanha torni maalissa
2. **Tricarico** (1,8 km): kapea vuoristotie harjanteen yli ja alas läntistä rinnettä,
   viinitarhat rinteillä
3. **Durazzano** (1,6 km): kukkulakylä, jonka läpi kulkee kapea mutkainen
   mukulakivikuja ja kellotorni, sitten itäisten viinitarhojen halki

**Egypt** (teema `desert`)
1. **Bawiti** (1,6 km): dyynit, kaktukset ja kolme keidasta; lähtö etelästä
2. **Giza** (1,6 km): jyrkät rinteet ja isot dyynit, lopuksi pitkä lenkki
   Gizan pyramidien ohi
3. **Ghamrin** (1,6 km): Niilin suiston pellot, kanavat, taatelipalmut ja
   egyptiläiset talot, välillä hiekkadyyneillä

Radat on lueteltu tiedostossa `js/tracks.js` (reitti, maasto, teema) ja autot
tiedostossa `js/cars.js` (vetotapa, teho, pito, massa ja ulkonäkö). Jokaisella autolla
on oma täydellinen ajosäätö `config`-kohdassa. Autojen mallit ovat vielä
placeholdereita.

Teemat (`js/themes.js`) määräävät taivaan, valaistuksen, maaston värit, tien
pinnan, pölyn värit ja maisemaelementit.

## Suorituskyky

- Maasto on jaettu 32 m paloihin, joiden tarkkuus riippuu etäisyydestä tiehen
  (`LOD_LEVELS` heightmap.js:ssä): tien lähellä 1,6 m ruudut, kauempana 3,2 m ja
  6,4 m. Saumat liitetään toisiinsa, joten rakoja ei synny, ja auto ajaa samalla
  pinnalla kuin näkyy.
- Maasto piirretään 64 m paloina ja puut, kivet ja muut toistuvat kappaleet 96 m
  ruutuina, joten näkymän ulkopuolisia paloja ei piirretä lainkaan.
- Maasto ei heitä varjoja (vain autot, puut ja rakennukset), näkymä päättyy sumun
  loppuun ja tarkkuus on enintään 1,5 × näytön pikseleistä (`main.js`).

## Ajanotto

Ajanotto käynnistyy, kun auto ylittää lähtöviivan, ja pysähtyy maaliviivalla.
Paras aika tallentuu selaimeen rata- ja autokohtaisesti: jos reittiä
muutetaan, ennätys alkaa alusta. Mutkia ei voi oikaista maaston kautta, sillä eteneminen
lasketaan vain, kun auto pysyy tien lähellä.

## Tien reitin muokkaus

Ratojen reitit ovat tiedostoissa `js/roadPath*.js` (katso tiedostolista alla):
lista `[x, z]`-pisteitä, joiden kautta
tie kulkee pehmeänä käyränä ensimmäisestä viimeiseen (tai lenkkinä, jos
`closed: true`). Samassa tiedostossa ovat lähtö- ja maaliviivan paikat. Siirrä, lisää tai poista
pisteitä ja päivitä sivu. Maasto muotoutuu tien mukaan automaattisesti
(leikkaukset ja penkereet), ja puut väistävät tietä. Samassa tiedostossa voi
säätää tien leveyttä, luiskien leveyttä, tasoitusta ja suurinta jyrkkyyttä.
Paina pelissä **M** nähdäksesi kartan, jossa pisteiden numerot näkyvät.

## Tiedostot

- `index.html`: sivu ja kirjastojen importmap
- `package.json`, `build.mjs`: npm-skriptit ja rakennus dist-kansioon
- `style.css`: HUD, valikko ja latausruutu
- `js/main.js`: käynnistys, pelisilmukka, valikon ja ajon vaihto
- `js/session.js`: yksi ajokerta (näkymä, fysiikka, rata, auto), rakennus ja purku
- `js/menu.js`: kaksiosainen päävalikko (rata, sitten auto)
- `js/tracks.js`, `js/cars.js`: valikon radat ja autot
- **Ratojen reitit (muokattavat):** `js/roadPath.js` (Harju),
  `roadPath_paijala.js`, `roadPath_ouninpohja.js`, `roadPath2.js` (Torrevecchia),
  `roadPath_tricarico.js`, `roadPath_durazzano.js`, `roadPath3.js` (Bawiti),
  `roadPath_giza.js`, `roadPath_ghamrin.js`
- `js/road.js`: tien keskilinja (spline) ja korkeusprofiili
- `js/heightmap.js`: luonnollinen maasto ja tien muotoilu maastoon, etäisyyskenttä
- `js/terrain.js`: maaston grafiikka ja törmäysmuoto
- `js/roadMesh.js`: soratien pinta
- `js/themes.js`: ratojen teemat (taivas, valot, värit, maisema)
- `js/scenery.js`: metsäteeman puut ja kivet
- `js/sceneryFinland.js`: hakkuuaukeat, pellot, paalit ja punaiset talot
- `js/sceneryTuscany.js`: Italian maisema (pellot, viinitarhat, talot, torni, puut, kylä)
- `js/sceneryDesert.js`: aavikko (keitaat, palmut, majat, kaktukset, pyramidit, suiston pellot ja talot)
- `js/sceneryKit.js`: maisemien yhteiset apufunktiot
- `js/car.js`: auton malli, jousitus ja ajologiikka; autojen säädöt ovat `cars.js`:ssä
- `js/dust.js`: pöly ja roiskeet renkaista; säädöt `DUST_CONFIG`-oliossa
- `js/stage.js`: lähtö- ja maaliportit, ajanotto ja ennätys
- `js/camera.js`: perässä seuraava kamera
- `js/mapView.js`: karttanäkymä
- `js/input.js`: näppäimistö
- `js/noise.js`: kohinafunktiot
