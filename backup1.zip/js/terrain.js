// Maaston grafiikka ja fysiikka valmiista korkeusdatasta (heightmap.js).
// Jokaisella kolmiolla on oma väri: flat-shaded polygonityyli ilman tekstuureita.

import * as THREE from 'three';
import { mulberry32 } from './noise.js';
import { TERRAIN_SIZE, SEGMENTS, HALF, CELL, N } from './heightmap.js';

/**
 * colorFn(col, info) asettaa kolmion värin (THREE.Color) teeman mukaan.
 * info = { x, z, h, slope, rd, flat, rand }: keskipiste, korkeus, normaalin y (1 = tasainen),
 * etäisyys tiehen, tien tasaisen osan leveys ja satunnaislukufunktio.
 */
export function createTerrain(scene, world, RAPIER, field, road, colorFn) {
  const { heights, roadDist } = field;

  // --- Fysiikka: kolmioverkko ----------------------------------------------
  const verts = new Float32Array(N * N * 3);
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      const k = (i * N + j) * 3;
      verts[k] = -HALF + j * CELL;
      verts[k + 1] = heights[i * N + j];
      verts[k + 2] = -HALF + i * CELL;
    }
  }
  const indices = new Uint32Array(SEGMENTS * SEGMENTS * 6);
  let t = 0;
  for (let i = 0; i < SEGMENTS; i++) {
    for (let j = 0; j < SEGMENTS; j++) {
      const a = i * N + j;          // (i, j)
      const b = (i + 1) * N + j;    // (i+1, j)
      const c = i * N + j + 1;      // (i, j+1)
      const d = (i + 1) * N + j + 1;
      indices[t++] = a; indices[t++] = b; indices[t++] = c;
      indices[t++] = c; indices[t++] = b; indices[t++] = d;
    }
  }

  const groundBody = world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
  world.createCollider(RAPIER.ColliderDesc.trimesh(verts, indices).setFriction(0.8), groundBody);

  // Näkymättömät seinät reunoille varmuuden vuoksi
  const wallPos = HALF - 3;
  for (const [wx, wz, hx, hz] of [
    [wallPos, 0, 1, HALF], [-wallPos, 0, 1, HALF],
    [0, wallPos, HALF, 1], [0, -wallPos, HALF, 1],
  ]) {
    world.createCollider(RAPIER.ColliderDesc.cuboid(hx, 150, hz).setTranslation(wx, 0, wz), groundBody);
  }

  // --- Grafiikka -------------------------------------------------------------
  const triCount = SEGMENTS * SEGMENTS * 2;
  const positions = new Float32Array(triCount * 9);
  const colors = new Float32Array(triCount * 9);

  const col = new THREE.Color();
  const rand = mulberry32(55);
  const info = { x: 0, z: 0, h: 0, slope: 1, rd: 0, flat: road.halfWidth + road.shoulder, rand };

  let p = 0;
  for (let tri = 0; tri < triCount; tri++) {
    const ia = indices[tri * 3], ib = indices[tri * 3 + 1], ic = indices[tri * 3 + 2];
    const ax = verts[ia * 3], ay = verts[ia * 3 + 1], az = verts[ia * 3 + 2];
    const bx = verts[ib * 3], by = verts[ib * 3 + 1], bz = verts[ib * 3 + 2];
    const cx = verts[ic * 3], cy = verts[ic * 3 + 1], cz = verts[ic * 3 + 2];

    // Normaalin y-komponentti: 1 = tasainen, 0 = pystysuora
    const e1x = bx - ax, e1y = by - ay, e1z = bz - az;
    const e2x = cx - ax, e2y = cy - ay, e2z = cz - az;
    const nx = e1y * e2z - e1z * e2y;
    const ny = e1z * e2x - e1x * e2z;
    const nz = e1x * e2y - e1y * e2x;
    const slopeY = ny / Math.hypot(nx, ny, nz);

    info.x = (ax + bx + cx) / 3;
    info.z = (az + bz + cz) / 3;
    info.h = (ay + by + cy) / 3;
    info.slope = slopeY;
    info.rd = (roadDist[ia] + roadDist[ib] + roadDist[ic]) / 3;
    colorFn(col, info);

    positions[p] = ax; positions[p + 1] = ay; positions[p + 2] = az;
    positions[p + 3] = bx; positions[p + 4] = by; positions[p + 5] = bz;
    positions[p + 6] = cx; positions[p + 7] = cy; positions[p + 8] = cz;
    for (let v = 0; v < 9; v += 3) {
      colors[p + v] = col.r; colors[p + v + 1] = col.g; colors[p + v + 2] = col.b;
    }
    p += 9;
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geometry.computeVertexNormals();

  const mesh = new THREE.Mesh(
    geometry,
    new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 1, metalness: 0 }),
  );
  mesh.receiveShadow = true;
  mesh.castShadow = true;
  scene.add(mesh);

  return {
    mesh,
    heightAt: field.heightAt,
    roadDistanceAt: field.roadDistanceAt,
    roadDistanceNearAt: field.roadDistanceNearAt,
    size: TERRAIN_SIZE,
    half: HALF,
  };
}
