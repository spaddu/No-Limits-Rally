// Suomalaisen metsäteeman lisät: hakkuuaukeat (kannot, hakkuutähteet, taimet)
// ja peltoaukeat (kaistapellot, säilörehupaalit, punaiset talot ja ladot).
// Vyöhykkeet annetaan tracks.js:ssä: scenery.clearcuts ja scenery.fields = [[x, z, säde], …].

import * as THREE from 'three';
import { createNoise2D, smoothstep } from './noise.js';
import {
  UP, slopeAt, flatMaterial, InstanceBatch, addCylinderCollider, addBoxCollider, gableRoofGeometry,
} from './sceneryKit.js';

const hash2 = (i, j) => {
  let h = (i * 374761393 + j * 668265263) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};

// Peltojen värit: ohra, nurmi, heinä, kynnös
const FIELD_COLORS = ['#cdbb5c', '#7fae46', '#a7b55b', '#6f5639'].map((c) => new THREE.Color(c));

/** Vyöhykkeet tai null (silloin metsä on kuten Harjun kierteessä). */
export function planFinland(terrain, road, options) {
  const clearcuts = options.clearcuts ?? [];
  const fields = options.fields ?? [];
  if (!clearcuts.length && !fields.length) return null;
  const edge = createNoise2D(515);
  const inside = (zones, x, z) => {
    let best = 0;
    for (const [cx, cz, r] of zones) {
      const rr = r * (1 + edge(x * 0.03, z * 0.03) * 0.18);   // rosoinen reuna
      const d = Math.hypot(x - cx, z - cz);
      if (d < rr) best = Math.max(best, 1 - d / rr);
    }
    return best;
  };
  const clearcutAt = (x, z) => inside(clearcuts, x, z);
  const fieldAt = (x, z) => inside(fields, x, z);
  return {
    clearcuts, fields, clearcutAt, fieldAt,
    zoneAt: (x, z) => Math.max(clearcutAt(x, z), fieldAt(x, z)),
    /** Peltokaistan tyyppi (FIELD_COLORS-indeksi) ja onko kohdalla oja. */
    stripAt: (x, z) => {
      const A = 0.35;
      const u = (x * Math.cos(A) + z * Math.sin(A)) / 22;
      const v = (-x * Math.sin(A) + z * Math.cos(A)) / 60;
      const iu = Math.floor(u), iv = Math.floor(v);
      return { type: Math.floor(hash2(iu, iv) * 4), ditch: u - iu < 0.06 };
    },
  };
}

/** Lisää metsän värityksen päälle hakkuuaukeat ja pellot. */
export function finlandOverlay(layout) {
  const cCutA = new THREE.Color('#8b8052');
  const cCutB = new THREE.Color('#9a8d5c');
  const cDitch = new THREE.Color('#557a35');
  const cEdge = new THREE.Color('#93a35a');
  const tmp = new THREE.Color();
  return (col, t) => {
    const cc = layout.clearcutAt(t.x, t.z);
    if (cc > 0) col.lerp(tmp.copy(cCutA).lerp(cCutB, (Math.sin(t.x * 0.7) * Math.cos(t.z * 0.6)) * 0.5 + 0.5), smoothstep(0, 0.12, cc));
    const f = layout.fieldAt(t.x, t.z);
    if (f > 0 && t.slope > 0.85) {
      const strip = layout.stripAt(t.x, t.z);
      col.lerp(cEdge, smoothstep(0, 0.06, f));
      if (f > 0.06) col.copy(strip.ditch ? cDitch : FIELD_COLORS[strip.type]);
    }
  };
}

/** Kannot, hakkuutähteet, taimet, paalit ja talot. */
export function buildFinland({ scene, world, RAPIER, terrain, road, layout, rand }) {
  if (!layout) return;
  const body = world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
  const flat = road.halfWidth + road.shoulder;
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const p = new THREE.Vector3();
  const s = new THREE.Vector3();
  const col = new THREE.Color();
  const H = (x, z) => terrain.heightAt(x, z);
  const randIn = ([cx, cz, r]) => {
    const a = rand() * 6.28, d = Math.sqrt(rand()) * r * 0.95;
    return [cx + Math.cos(a) * d, cz + Math.sin(a) * d];
  };

  // --- Hakkuuaukeat ----------------------------------------------------------------
  const stumps = new InstanceBatch(new THREE.CylinderGeometry(0.28, 0.34, 0.55, 7).translate(0, 0.27, 0), flatMaterial('#7a5b3c'));
  const slash = new InstanceBatch(new THREE.DodecahedronGeometry(0.5, 0), flatMaterial('#ffffff'), { castShadow: false });
  const saplings = new InstanceBatch(new THREE.ConeGeometry(0.5, 1.6, 6).translate(0, 0.8, 0), flatMaterial('#ffffff'));
  for (const zone of layout.clearcuts) {
    const n = Math.round(zone[2] * zone[2] * 0.012);
    for (let i = 0; i < n; i++) {
      const [x, z] = randIn(zone);
      if (terrain.roadDistanceAt(x, z) < flat + 2) continue;
      const y = H(x, z);
      const r = rand();
      if (r < 0.45) {
        const sc = 0.8 + rand() * 0.6;
        m.compose(p.set(x, y - 0.12, z), q.setFromAxisAngle(UP, rand() * 6.28), s.set(sc, 0.8 + rand() * 0.6, sc));
        stumps.add(m);
        addCylinderCollider(world, RAPIER, body, x, y - 0.1, z, 0.5, 0.3 * sc);
      } else if (r < 0.75) {
        const sc = 0.6 + rand() * 1.0;
        m.compose(p.set(x, y + 0.05, z), q.setFromAxisAngle(UP, rand() * 6.28), s.set(sc * 2, sc * 0.5, sc * 1.2));
        slash.add(m, col.setHSL(0.08, 0.25, 0.32 + rand() * 0.12));
      } else {
        const sc = 0.5 + rand() * 1.1;
        m.compose(p.set(x, y - 0.05, z), q.setFromAxisAngle(UP, rand() * 6.28), s.set(sc, sc, sc));
        saplings.add(m, col.set('#3d7f3e').multiplyScalar(0.85 + rand() * 0.3));
      }
    }
  }
  stumps.build(scene);
  slash.build(scene);
  saplings.build(scene);

  // --- Pellot: säilörehupaalit -------------------------------------------------------
  const bales = new InstanceBatch(new THREE.CylinderGeometry(0.65, 0.65, 1.2, 12).rotateZ(Math.PI / 2), flatMaterial('#f1f1ec'));
  const taken = [];
  for (const zone of layout.fields) {
    const groups = 2 + Math.floor(rand() * 2);
    for (let g = 0; g < groups; g++) {
      const [gx, gz] = randIn(zone);
      if (terrain.roadDistanceAt(gx, gz) < flat + 6) continue;
      const yaw0 = rand() * 6.28;
      const n = 3 + Math.floor(rand() * 6);
      for (let i = 0; i < n; i++) {
        const x = gx + Math.cos(yaw0) * i * 1.5 + (rand() - 0.5) * 0.3;
        const z = gz + Math.sin(yaw0) * i * 1.5 + (rand() - 0.5) * 0.3;
        if (terrain.roadDistanceAt(x, z) < flat + 3) continue;
        const yaw = -yaw0 + Math.PI / 2 + (rand() - 0.5) * 0.2;
        m.compose(p.set(x, H(x, z) + 0.62, z), q.setFromAxisAngle(UP, yaw), s.set(1, 1, 1));
        bales.add(m);
        addBoxCollider(world, RAPIER, body, x, H(x, z) + 0.65, z, 0.6, 0.65, 0.65, yaw);
      }
      taken.push([gx, gz, 8]);
    }
  }
  bales.build(scene);

  // --- Punainen talo ja lato pellon laidalle -------------------------------------------
  const red = flatMaterial('#9a2c1f');
  const white = flatMaterial('#f2efe6');
  const roofDark = flatMaterial('#3a3b3f');
  const glass = flatMaterial('#2b3540');
  const barnRed = flatMaterial('#8a2a1e');
  for (const zone of layout.fields) {
    for (let attempt = 0; attempt < 80; attempt++) {
      const a = rand() * 6.28, d = zone[2] * (0.6 + rand() * 0.35);
      const x = zone[0] + Math.cos(a) * d, z = zone[1] + Math.sin(a) * d;
      const rd = terrain.roadDistanceAt(x, z);
      if (rd < 16 || rd > 45 || slopeAt(terrain, x, z) > 0.15 || taken.some(([tx, tz, tr]) => Math.hypot(tx - x, tz - z) < tr + 10)) continue;
      // Etuseinä kohti lähintä tienkohtaa (karkea haku)
      let bs = 0, bd = Infinity;
      for (let k = 0; k < road.count; k += 4) {
        const dd = (road.xs[k] - x) ** 2 + (road.zs[k] - z) ** 2;
        if (dd < bd) { bd = dd; bs = k; }
      }
      const yaw = Math.atan2(road.xs[bs] - x, road.zs[bs] - z);
      const base = Math.min(H(x, z), H(x + 5, z), H(x - 5, z), H(x, z + 5), H(x, z - 5)) - 0.4;
      const g = new THREE.Group();
      g.position.set(x, base, z);
      g.rotation.y = yaw;
      const add = (geo, mat, px, py, pz) => {
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(px, py, pz);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        g.add(mesh);
      };
      // Asuinrakennus
      const wh = 4.2;
      add(new THREE.BoxGeometry(9, wh, 6), red, 0, wh / 2, 0);
      add(gableRoofGeometry(9, 2.2, 6, 0.4), roofDark, 0, wh + 1.1, 0);
      for (const [cx, cz] of [[4.5, 3], [-4.5, 3], [4.5, -3], [-4.5, -3]]) add(new THREE.BoxGeometry(0.25, wh, 0.25), white, cx, wh / 2, cz);
      for (const wx of [-2.8, 0, 2.8]) {
        add(new THREE.BoxGeometry(1.2, 1.3, 0.08), white, wx, 2.5, 3.02);
        add(new THREE.BoxGeometry(0.9, 1.0, 0.1), glass, wx, 2.5, 3.04);
      }
      add(new THREE.BoxGeometry(1.1, 2.1, 0.1), white, -4.0 + 0.8, 1.45, 3.03);
      add(new THREE.BoxGeometry(0.7, 1.4, 0.7), red, 2, wh + 1.7, -1);   // savupiippu
      // Lato sivulla
      add(new THREE.BoxGeometry(11, 5, 7.5), barnRed, 13, 2.5, -4);
      add(gableRoofGeometry(11, 2.6, 7.5, 0.4), roofDark, 13, 5 + 1.3, -4);
      add(new THREE.BoxGeometry(3.6, 3.6, 0.1), white, 13, 1.8, -0.2);
      scene.add(g);
      const cos = Math.cos(yaw), sin = Math.sin(yaw);
      addBoxCollider(world, RAPIER, body, x, base + wh / 2, z, 4.6, wh / 2 + 0.5, 3.1, yaw);
      addBoxCollider(world, RAPIER, body, x + 13 * cos - 4 * sin, base + 2.5, z - 13 * sin - 4 * cos, 5.6, 2.8, 3.8, yaw);
      taken.push([x, z, 20]);
      break;
    }
  }
}
