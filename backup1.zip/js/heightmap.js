// Maaston korkeusdata ilman grafiikkaa: luonnollinen maasto kohinasta,
// johon tie "rakennetaan" leikkauksineen ja penkereineen.
// Tiedosto ei riipu Three.js:stä, joten sitä voi ajaa myös Nodella.

import { createNoise2D, fbm, smoothstep } from './noise.js';

export const TERRAIN_SIZE = 640;   // metriä sivulla
export const SEGMENTS = 400;       // ruutuja sivulla (1,6 m ruutu)
export const HALF = TERRAIN_SIZE / 2;
export const CELL = TERRAIN_SIZE / SEGMENTS;
export const N = SEGMENTS + 1;     // pisteitä sivulla

/**
 * Maaston oletusasetukset. Radat voivat muuttaa näitä (tracks.js):
 * seed vaihtaa koko maaston muodon, muut säätävät mäkien kokoa.
 */
export const DEFAULT_TERRAIN = {
  seed: null,         // null = rata 1:n alkuperäinen maasto, numero = uusi maasto
  hills: 40,          // isojen mäkien korkeus (m)
  hillScale: 0.0095,  // isojen mäkien tiheys (suurempi = tiheämpiä mäkiä)
  ridges: 14,         // terävien harjanteiden korkeus (m)
  bumps: 2.4,         // pienten kumpareiden korkeus (m)
  rim: 40,            // reunavuorten korkeus (m)
  ridgeScale: [0.013, 0.013], // harjanteiden tiheys x- ja z-suunnassa (eri luvut = venytetyt dyynit)
  basins: [],         // painanteet [x, z, säde, syvyys], esim. keitaat
  plateaus: [],       // tasanteet [x, z, säde, korkeus], esim. kylä tai pyramidit
  lowland: null,      // alanko [dx, dz, siirtymä, leveys, kerroin]: suunnan (dx, dz) puolella maasto madaltuu
};

/** Luo funktion naturalHeight(x, z): luonnollinen maasto ilman tietä. */
export function createNaturalHeight(params = {}) {
  const P = { ...DEFAULT_TERRAIN, ...params };
  const seeds = P.seed == null ? [1337, 9001, 4242, 777] : [P.seed, P.seed * 7 + 1, P.seed * 3 + 2, P.seed + 99];
  const hills = createNoise2D(seeds[0]);
  const ridges = createNoise2D(seeds[1]);
  const bumps = createNoise2D(seeds[2]);
  const rim = createNoise2D(seeds[3]);

  return function naturalHeight(x, z) {
    // Isot mäet ja laaksot
    let h = fbm(hills, x * P.hillScale, z * P.hillScale, 4, 2, 0.5) * P.hills;
    // Terävät harjanteet: kohinan "taitekohdat" nostetaan kapeiksi selänteiksi
    const rr = 1 - Math.abs(ridges(x * P.ridgeScale[0], z * P.ridgeScale[1]));
    h += rr * rr * rr * P.ridges - P.ridges * (5 / 14);
    // Pienemmät kumpareet, joista saa hyppyjä
    h += bumps(x * 0.05, z * 0.05) * P.bumps;

    // Alanko (esim. jokisuisto): toisella puolella maasto tasoittuu kertoimen verran
    if (P.lowland) {
      const [dx, dz, off, width, factor] = P.lowland;
      const t = smoothstep(off - width / 2, off + width / 2, x * dx + z * dz);
      h *= 1 + (factor - 1) * t;
    }

    // Tasanteet: maasto tasoittuu annettuun korkeuteen, reunoilla pehmeä siirtymä
    for (const [px, pz, pr, ph] of P.plateaus) {
      const d = Math.hypot(x - px, z - pz);
      if (d < pr) {
        const t = smoothstep(pr, pr * 0.6, d);
        h += (ph - h) * t;
      }
    }

    // Painanteet (keitaat): maasto laskee loivasti kohti keskustaa
    for (const [bx, bz, br, depth] of P.basins) {
      const d = Math.hypot(x - bx, z - bz);
      if (d < br) {
        const t = 1 - d / br;
        h -= depth * t * t * (3 - 2 * t);
      }
    }

    // Reunoille nousevat vuoret rajaamaan alueen
    const edge = Math.max(Math.abs(x), Math.abs(z)) / HALF;
    const r = smoothstep(0.8, 1.0, edge);
    h += r * r * (P.rim + rim(x * 0.02, z * 0.02) * 15);

    return h;
  };
}

/**
 * Laskee korkeusruudukon, johon tie on muotoiltu, sekä etäisyyskentän
 * (jokaisen ruudukkopisteen etäisyys tien keskilinjaan).
 */
export function buildHeightfield(road, naturalHeight) {
  const heights = new Float32Array(N * N);   // [rivi z][sarake x]
  const roadDist = new Float32Array(N * N).fill(1e6);
  const roadH = new Float32Array(N * N);

  for (let i = 0; i < N; i++) {
    const z = -HALF + i * CELL;
    for (let j = 0; j < N; j++) {
      heights[i * N + j] = naturalHeight(-HALF + j * CELL, z);
    }
  }

  // --- Etäisyyskenttä: käydään läpi tien janat ja niiden lähiruudut ------
  const flat = road.halfWidth + road.shoulder;  // tasainen osa keskilinjasta
  const reach = flat + road.blend + 2;          // kuinka kauas tie vaikuttaa
  const { xs, zs, hs, count } = road;
  for (let s = 0; s < road.segCount; s++) {
    const s2 = (s + 1) % count;
    const ax = xs[s], az = zs[s], bx = xs[s2], bz = zs[s2];
    const dx = bx - ax, dz = bz - az;
    const len2 = dx * dx + dz * dz || 1e-9;
    const j0 = Math.max(0, Math.floor((Math.min(ax, bx) - reach + HALF) / CELL));
    const j1 = Math.min(N - 1, Math.ceil((Math.max(ax, bx) + reach + HALF) / CELL));
    const i0 = Math.max(0, Math.floor((Math.min(az, bz) - reach + HALF) / CELL));
    const i1 = Math.min(N - 1, Math.ceil((Math.max(az, bz) + reach + HALF) / CELL));
    for (let i = i0; i <= i1; i++) {
      const pz = -HALF + i * CELL;
      for (let j = j0; j <= j1; j++) {
        const px = -HALF + j * CELL;
        let t = ((px - ax) * dx + (pz - az) * dz) / len2;
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const qx = ax + dx * t - px;
        const qz = az + dz * t - pz;
        const d = Math.sqrt(qx * qx + qz * qz);
        const k = i * N + j;
        if (d < roadDist[k]) {
          roadDist[k] = d;
          roadH[k] = hs[s] + (hs[s2] - hs[s]) * t;
        }
      }
    }
  }

  // --- Tie maastoon: tasainen tienpohja ja luiskat luonnolliseen maahan ---
  for (let k = 0; k < N * N; k++) {
    const d = roadDist[k];
    if (d >= reach) continue;
    const t = smoothstep(flat, flat + road.blend, d);
    heights[k] = roadH[k] + (heights[k] - roadH[k]) * t;
  }

  const sample = (arr, x, z) => {
    const gx = Math.min(Math.max((x + HALF) / CELL, 0), SEGMENTS - 1e-4);
    const gz = Math.min(Math.max((z + HALF) / CELL, 0), SEGMENTS - 1e-4);
    const j = Math.floor(gx);
    const i = Math.floor(gz);
    const u = gx - j;
    const v = gz - i;
    const a00 = arr[i * N + j];
    const a10 = arr[i * N + j + 1];
    const a01 = arr[(i + 1) * N + j];
    const a11 = arr[(i + 1) * N + j + 1];
    // Sama kolmiojako kuin maastomeshissä, joten korkeus vastaa pintaa tarkasti
    if (u + v <= 1) return a00 + (a10 - a00) * u + (a01 - a00) * v;
    return a11 + (a01 - a11) * (1 - u) + (a10 - a11) * (1 - v);
  };

  // --- Karkea etäisyyskenttä koko alueelle (8 m ruudut) maiseman sijoittelua varten
  const CC = 8;
  const CN = Math.round(TERRAIN_SIZE / CC) + 1;
  const coarse = new Float32Array(CN * CN);
  for (let i = 0; i < CN; i++) {
    const z = -HALF + i * CC;
    for (let j = 0; j < CN; j++) {
      const x = -HALF + j * CC;
      let best = Infinity;
      for (let s = 0; s < count; s += 2) {
        const d = (xs[s] - x) ** 2 + (zs[s] - z) ** 2;
        if (d < best) best = d;
      }
      coarse[i * CN + j] = Math.sqrt(best);
    }
  }
  const coarseAt = (x, z) => {
    const gx = Math.min(Math.max((x + HALF) / CC, 0), CN - 1.0001);
    const gz = Math.min(Math.max((z + HALF) / CC, 0), CN - 1.0001);
    const j = Math.floor(gx), i = Math.floor(gz);
    const u = gx - j, v = gz - i;
    const a = coarse[i * CN + j], b = coarse[i * CN + j + 1];
    const c = coarse[(i + 1) * CN + j], d = coarse[(i + 1) * CN + j + 1];
    return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v;
  };

  return {
    heights,
    roadDist,
    /** Maaston korkeus kohdassa (x, z). */
    heightAt: (x, z) => sample(heights, x, z),
    /** Vain tien lähikenttä (kaukana suuri luku); Harjun metsä on sijoiteltu tämän mukaan. */
    roadDistanceNearAt: (x, z) => sample(roadDist, x, z),
    /** Etäisyys tien keskilinjaan (m). Tien lähellä tarkka, kauempana karkea arvio. */
    roadDistanceAt: (x, z) => {
      const d = sample(roadDist, x, z);
      return d < reach - 1 ? d : Math.max(coarseAt(x, z), reach - 1);
    },
  };
}
