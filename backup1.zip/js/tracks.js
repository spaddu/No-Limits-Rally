// =============================================================================
//  RADAT – valikossa näkyvät radat maittain
// =============================================================================
//  Jokaisella radalla on reitti (roadPath*.js), oma maasto ja teema.
//  country: valikon ryhmä. theme: 'forest' (Suomi), 'tuscany' (Italia), 'desert' (Egypti).
//
//  terrain-asetukset (katso DEFAULT_TERRAIN heightmap.js:ssä):
//    seed      maaston muoto (null = Harjun alkuperäinen maasto)
//    hills     isojen mäkien korkeus (m)        hillScale isojen mäkien tiheys
//    ridges    harjanteiden korkeus (m)          ridgeScale harjanteiden tiheys [x, z]
//    bumps     pienten kumpareiden korkeus (m)   rim       reunavuorten korkeus (m)
//    basins    painanteet [x, z, säde, syvyys] (keitaat)
//    plateaus  tasanteet [x, z, säde, korkeus] (kylä, pyramidit)
//    lowland   alanko [dx, dz, siirtymä, leveys, kerroin] (Niilin suisto)
//
//  scenery-asetukset riippuvat teemasta:
//    forest:  trees, forestCover (tiheys), clearcuts ja fields [[x, z, säde], …],
//             legacyDistance (vain Harju)
//    tuscany: houses, vineyards, landmark [x, z], village { from, to } (m tien alusta),
//             meadow (niittyjen osuus), groves, pines, cypressRows, bales, rocks
//    desert:  pyramids [[x, z, kanta, korkeus], …], houses, palms, rocks
//  env: taivaan tai sumun muutos, esim. { fog: [lähellä, kaukana] }.
//  color = valikon kortin väri.
// =============================================================================

import { ROAD as HARJU } from './roadPath.js';
import { ROAD as PAIJALA } from './roadPath_paijala.js';
import { ROAD as OUNINPOHJA } from './roadPath_ouninpohja.js';
import { ROAD as TORREVECCHIA } from './roadPath2.js';
import { ROAD as TRICARICO } from './roadPath_tricarico.js';
import { ROAD as DURAZZANO } from './roadPath_durazzano.js';
import { ROAD as BAWITI } from './roadPath3.js';
import { ROAD as GIZA } from './roadPath_giza.js';
import { ROAD as GHAMRIN } from './roadPath_ghamrin.js';

export const COUNTRIES = ['Finland', 'Italy', 'Egypt'];

export const TRACKS = [
  // --- Finland -------------------------------------------------------------------
  {
    id: 'harju',
    country: 'Finland',
    name: 'Harju',
    description: 'Hilly, twisty forest stage with three big climbs',
    color: '#3f8f4a',
    theme: 'forest',
    road: HARJU,
    terrain: {},
    scenery: { trees: 2600, seed: 99, legacyDistance: true },
  },
  {
    id: 'paijala',
    country: 'Finland',
    name: 'Päijälä',
    description: 'Dense forest, short steep crests, tight bends and clear-cuts',
    color: '#2d6a3a',
    theme: 'forest',
    road: PAIJALA,
    terrain: { seed: 4321, hills: 16, hillScale: 0.017, ridges: 7, ridgeScale: [0.02, 0.02], bumps: 2.2, rim: 40 },
    scenery: { trees: 4200, seed: 41, forestCover: 0.25, clearcuts: [[-130, 150, 45], [20, 15, 42], [120, -110, 45]] },
  },
  {
    id: 'ouninpohja',
    country: 'Finland',
    name: 'Ouninpohja',
    description: 'The long one: fast straights, tight corners, forests and open fields',
    color: '#5c8a3c',
    theme: 'forest',
    road: OUNINPOHJA,
    terrain: { seed: 7777, hills: 26, hillScale: 0.007, ridges: 5, bumps: 1.4, rim: 38 },
    scenery: {
      trees: 4000, seed: 77, forestCover: 0.15,
      fields: [[-120, 236, 62], [70, 60, 58], [110, -14, 62], [-110, -152, 55]],
      clearcuts: [[-200, -95, 40]],
    },
  },

  // --- Italy -----------------------------------------------------------------------
  {
    id: 'torrevecchia',
    country: 'Italy',
    name: 'Torrevecchia',
    description: 'Through the Italian hills past vineyards and farmhouses, finishing at the old tower',
    color: '#c27a43',
    theme: 'tuscany',
    road: TORREVECCHIA,
    terrain: { seed: 5150, hills: 34, hillScale: 0.0065, ridges: 3, bumps: 0.9, rim: 38 },
    scenery: { seed: 12, houses: 6, vineyards: 9, landmark: [-55, -110] },
  },
  {
    id: 'tricarico',
    country: 'Italy',
    name: 'Tricarico',
    description: 'Narrow mountain roads climbing over the ridge, vineyards on the slopes',
    color: '#9a6a48',
    theme: 'tuscany',
    road: TRICARICO,
    terrain: { seed: 6060, hills: 58, hillScale: 0.0075, ridges: 10, bumps: 1.0, rim: 55 },
    scenery: { seed: 23, houses: 3, vineyards: 12, meadow: 0.6, groves: 3, pines: 14, cypressRows: 2, bales: 10, rocks: 120 },
  },
  {
    id: 'durazzano',
    country: 'Italy',
    name: 'Durazzano',
    description: 'Vineyards and a hilltop village with a narrow, twisting alley',
    color: '#b8893f',
    theme: 'tuscany',
    road: DURAZZANO,
    terrain: { seed: 9090, hills: 26, hillScale: 0.007, ridges: 3, bumps: 0.7, rim: 40, plateaus: [[-82, 88, 75, 9]] },
    scenery: { seed: 17, houses: 4, vineyards: 12, meadow: 0.45, village: { from: 225, to: 360 } },
  },

  // --- Egypt ------------------------------------------------------------------------
  {
    id: 'bawiti',
    country: 'Egypt',
    name: 'Bawiti',
    description: 'Over the dunes of the Egyptian desert and through its oases',
    color: '#d6a95a',
    theme: 'desert',
    road: BAWITI,
    terrain: {
      seed: 808, hills: 20, hillScale: 0.006, ridges: 12, ridgeScale: [0.009, 0.022], bumps: 1.2, rim: 45,
      basins: [[-82, 38, 40, 4.5], [102, 76, 40, 4.5], [196, -122, 38, 4.5]],
    },
    scenery: { seed: 31 },
  },
  {
    id: 'giza',
    country: 'Egypt',
    name: 'Giza',
    description: 'Steep slopes and big dunes with the pyramids on the horizon',
    color: '#c99a5c',
    theme: 'desert',
    road: GIZA,
    terrain: {
      seed: 2560, hills: 30, hillScale: 0.008, ridges: 18, ridgeScale: [0.008, 0.02], bumps: 1.5, rim: 16,
      plateaus: [[205, -205, 125, 2]],
    },
    scenery: { seed: 61, pyramids: [[190, -190, 100, 64], [112, -242, 80, 52], [246, -128, 44, 28]] },
    env: { fog: [220, 820] },
  },
  {
    id: 'ghamrin',
    country: 'Egypt',
    name: 'Ghamrin',
    description: 'Nile Delta farm roads lined with houses, then into the sand',
    color: '#7f9f4a',
    theme: 'desert',
    road: GHAMRIN,
    terrain: {
      seed: 1313, hills: 20, hillScale: 0.007, ridges: 12, ridgeScale: [0.01, 0.022], bumps: 1.0, rim: 30,
      lowland: [-0.95, 0.31, 10, 90, 0.1],
    },
    scenery: { seed: 19, houses: 16, palms: 90 },
  },
];
