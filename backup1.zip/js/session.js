// Yksi ajokerta valitulla radalla ja autolla: oma 3D-näkymä, fysiikkamaailma,
// maasto, tie, auto, ajanotto ja efektit. Radan tai auton vaihtuessa vanha
// sessio puretaan (dispose) ja tilalle rakennetaan uusi.

import * as THREE from 'three';
import { createNaturalHeight, buildHeightfield, HALF, TERRAIN_SIZE } from './heightmap.js';
import { mulberry32 } from './noise.js';
import { THEMES } from './themes.js';
import { buildRoad } from './road.js';
import { createRoadMesh, nearestRoadSample } from './roadMesh.js';
import { createTerrain } from './terrain.js';
import { Car } from './car.js';
import { ChaseCamera } from './camera.js';
import { MapView } from './mapView.js';
import { DustSystem } from './dust.js';
import { Stage } from './stage.js';

export const STEP = 1 / 60;
const SUN_OFFSET = new THREE.Vector3(45, 80, 30);

export class RaceSession {
  constructor(RAPIER, track, carDef) {
    const buildStart = performance.now();
    this.track = track;
    this.carDef = carDef;

    // --- Näkymä ja valot (teeman mukaan) ---------------------------------------------
    const theme = THEMES[track.theme ?? 'forest'];
    this.theme = theme;
    const scene = new THREE.Scene();
    // Rata voi muuttaa teeman taivasta ja sumua (track.env), esim. pyramidit näkyviin kauas
    const sky = new THREE.Color(track.env?.sky ?? theme.sky);
    const fog = track.env?.fog ?? theme.fog;
    scene.background = sky;
    scene.fog = new THREE.Fog(sky, fog[0], fog[1]);
    scene.add(new THREE.HemisphereLight(...theme.hemi));
    const sun = new THREE.DirectionalLight(theme.sun[0], theme.sun[1]);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera;
    sc.left = -45; sc.right = 45; sc.top = 45; sc.bottom = -45;
    sc.near = 10; sc.far = 220;
    sun.shadow.bias = -0.0005;
    sun.shadow.normalBias = 0.04;
    scene.add(sun, sun.target);
    this.scene = scene;
    this.sun = sun;
    this.camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 900);

    // --- Fysiikka ja maailma -----------------------------------------------------
    const world = new RAPIER.World({ x: 0, y: -14, z: 0 }); // hieman maata vahvempi painovoima = napakampi arcade-tuntuma
    world.timestep = STEP;
    this.world = world;

    const naturalHeight = createNaturalHeight(track.terrain);
    const road = buildRoad(track.road, naturalHeight);   // tien keskilinja ja korkeusprofiili
    const field = buildHeightfield(road, naturalHeight); // maasto, johon tie on muotoiltu
    this.road = road;
    // Maisemasuunnitelma (pellot, keitaat…) ennen maaston värjäystä
    const info = { heightAt: field.heightAt, roadDistanceAt: field.roadDistanceAt, half: HALF, size: TERRAIN_SIZE };
    const options = track.scenery ?? {};
    const rand = mulberry32(options.seed ?? 99);
    const layout = theme.plan(info, road, options, rand, track);
    this.layout = layout;
    this.terrain = createTerrain(scene, world, RAPIER, field, road, theme.terrainColor(layout));
    createRoadMesh(scene, road, theme.road, layout?.roadAlt ?? null);
    theme.build({ scene, world, RAPIER, terrain: this.terrain, road, layout, rand, options, track });
    this.stage = new Stage(scene, world, RAPIER, road, carDef.id);

    // --- Auto ------------------------------------------------------------------------
    const roadEdge = road.halfWidth + road.shoulder;
    this.car = new Car(scene, world, RAPIER, { x: 0, y: 50, z: 0 }, carDef);
    this.car.isOnRoad = (x, z) => this.terrain.roadDistanceAt(x, z) < roadEdge;
    this.placeOnRoad(this.stage.spawnS);

    this.chase = new ChaseCamera(this.camera, this.terrain);
    this.car.syncVisual(1);
    this.chase.snap(this.car.position, this.car.forward);
    this.mapView = new MapView(scene, this.terrain, road, this.stage);
    this.dust = new DustSystem(scene, theme.dust);

    this.accumulator = 0;
    this.orbitAngle = 0;
    this.driven = false;   // onko tällä sessiolla jo ajettu (valikon "Jatka"-nappia varten)
    console.info(`${track.name} + ${carDef.name}: rakennettu ${Math.round(performance.now() - buildStart)} ms, tie ${Math.round(road.length)} m`);
  }

  /** Siirtää auton tien näytepisteeseen s, ajosuuntaan (tai vastakkaiseen, jos reverse). */
  placeOnRoad(s, reverse = false) {
    const r = this.road;
    let yaw = Math.atan2(-r.tz[s], r.tx[s]);
    if (reverse) yaw += Math.PI;
    this.car.placeAt(r.xs[s], r.hs[s] + 1.2, r.zs[s], yaw);
  }

  /** Palauttaa auton lähimpään kohtaan tiellä, nokka sinne päin kuin auto osoitti. */
  returnToRoad() {
    const r = this.road;
    const car = this.car;
    const s = nearestRoadSample(r, car.currPos.x, car.currPos.z);
    const along = car.forward.x * r.tx[s] + car.forward.z * r.tz[s];
    this.placeOnRoad(s, along < 0);
  }

  /** Uusi yritys: auto lähtöviivalle ja ajanotto nollaan. */
  restart() {
    this.placeOnRoad(this.stage.spawnS);
    this.stage.reset();
    this.car.syncVisual(1);
    this.chase.snap(this.car.position, this.car.forward);
  }

  stepPhysics(inputState) {
    const car = this.car;
    car.savePrev();
    car.update(inputState, STEP);
    this.world.step();
    car.afterStep();
    this.stage.update(STEP, car.currPos);
    if (car.currPos.y < -60) this.returnToRoad();
  }

  /** Ajotila: fysiikka, efektit ja perässä seuraava kamera. */
  drive(dt, input) {
    this.driven = true;
    if (input.consumeReset()) this.car.reset(this.terrain);
    if (input.consumeRoad()) this.returnToRoad();
    if (input.consumeMap()) this.mapView.toggle();
    if (input.consumeRestart()) this.restart();

    this.accumulator += dt;
    while (this.accumulator >= STEP) {
      this.stepPhysics(input.state);
      this.accumulator -= STEP;
    }
    const car = this.car;
    car.syncVisual(this.accumulator / STEP);
    this.dust.emit(car, dt);
    this.dust.update(dt, this.camera.position);
    this.chase.update(dt, car.position, car.forward);
    this.mapView.update(car);
    this.stage.updateHud();
    this.followSun();
  }

  /** Valikkotila: fysiikka tauolla, kamera kiertää hitaasti auton ympäri. */
  idle(dt) {
    const p = this.car.position;
    this.orbitAngle += dt * 0.18;
    const a = this.orbitAngle;
    this.camera.position.set(p.x + Math.cos(a) * 10, p.y + 3.8, p.z + Math.sin(a) * 10);
    const ground = this.terrain.heightAt(this.camera.position.x, this.camera.position.z) + 1.5;
    if (this.camera.position.y < ground) this.camera.position.y = ground;
    this.camera.lookAt(p.x, p.y + 0.6, p.z);
    this.dust.update(dt, this.camera.position);
    this.followSun();
  }

  followSun() {
    this.sun.position.copy(this.car.position).add(SUN_OFFSET);
    this.sun.target.position.copy(this.car.position);
  }

  render(renderer) {
    renderer.render(this.scene, this.mapView.active ? this.mapView.camera : this.camera);
  }

  resize() {
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
    this.mapView.resize();
  }

  /** Vapauttaa näytönohjaimen ja fysiikan resurssit. */
  dispose() {
    this.stage.dispose();
    this.scene.traverse((obj) => {
      obj.geometry?.dispose();
      const mats = Array.isArray(obj.material) ? obj.material : obj.material ? [obj.material] : [];
      for (const m of mats) {
        m.map?.dispose();
        m.dispose();
      }
      if (obj.isInstancedMesh) obj.dispose();
    });
    this.sun.shadow.map?.dispose();
    this.world.free();
  }
}
