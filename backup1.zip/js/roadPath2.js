// =============================================================================
//  RATA 2: TORREVECCHIA
// =============================================================================
//  Strada bianca Italian kukkuloilla: laaksosta mäen laelle vanhan tornin luo.
//  Sama muoto kuin roadPath.js:ssä (katso ohjeet sieltä). Maaston ja maiseman
//  asetukset ovat tracks.js:ssä.
// =============================================================================

export const ROAD = {
  closed: false,
  startAt: 15,
  finishAt: -45,

  width: 4.5,
  shoulder: 1.5,
  blend: 8,
  smoothing: 4,
  maxGrade: 0.3,
  spacing: 1,

  points: [
    [120, 235], // 0 lähtöalue
    [160, 240], // 1
    [195, 220], // 2
    [215, 185], // 3
    [195, 150], // 4
    [160, 160], // 5
    [125, 130], // 6
    [130, 85],  // 7
    [95, 55],   // 8 laakson pohja
    [50, 75],   // 9
    [15, 40],   // 10
    [35, 0],    // 11
    [10, -40],  // 12
    [-35, -25], // 13
    [-75, -50], // 14
    [-110, -25], // 15
    [-150, -55], // 16
    [-130, -100], // 17 nousu harjulle
    [-95, -120], // 18
    [-75, -160], // 19
    [-40, -150], // 20
    [-15, -120], // 21
    [-40, -95], // 22 torni lähellä, maali
    [-75, -80], // 23 tien loppu
  ],
};
