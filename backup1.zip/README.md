# No Limits Rally

Pieni 3D-rallipeli: valitse rata ja auto valikosta ja aja pätkä
mäkien ja metsien keskellä mahdollisimman nopeasti.

## Käynnistys

Tarvitset Node.js:n. Aja projektikansiossa:

```
npx serve
```

Avaa sitten selaimessa http://localhost:3000.

Kirjastot (Three.js ja Rapier) ladataan CDN:stä, joten `npm install` -komentoa ei tarvita.

## Ohjaus

Pelin tekstit ovat englanniksi. Ohjeet näkyvät myös päävalikon alareunassa.

| Näppäin | Toiminto |
|---|---|
| W / ↑ | Kaasu |
| S / ↓ | Jarru, pysähtyneenä peruutus |
| A / D tai ← / → | Ohjaus (ilmassa: auton kääntö) |
| Välilyönti | Käsijarru |
| R | Nosta auto pystyyn |
| T | Takaisin tielle (lähimpään kohtaan) |
| M | Kartta (näyttää reitin ja reittipisteiden numerot) |
| Enter | Uusi yritys (auto lähtöviivalle, ajanotto nollaan) |
| Esc | Valikko (ajo pysähtyy, Esc uudelleen jatkaa) |

## Valikko, radat ja autot

Valikko on kaksiosainen: ensin valitaan rata (maittain ryhmiteltynä) ja sitten
auto. Nuolinäppäimet tai WASD valitsevat, Enter siirtyy seuraavaan vaiheeseen ja
autovaiheessa käynnistää ajon. Esc palaa autovalinnasta ratavalintaan ja
ratavalinnasta takaisin ajoon. Ratakortissa näkyy pätkän pituus ja paras aika
millä tahansa autolla; autokortissa paras aika valitulla radalla.

**Finland** (teema `forest`)
1. **Harjun kierre**: mäkinen metsäpätkä, kolme isoa nousua
2. **Päijälä**: tiheä metsä, lyhyet jyrkät mäet, tiukat mutkat ja hakkuuaukeat
3. **Ouninpohja**: noin kaksi kertaa muita pidempi (1,9 km); metsää, nopeita
   suoria, tiukkoja mutkia ja peltoaukeita punaisine taloineen ja paaleineen

**Italy** (teema `tuscany`)
1. **Torrevecchia**: kukkulat, viinitarhat, maatalot ja vanha torni maalissa
2. **Tricarico**: kapea vuoristotie harjanteen yli, viinitarhat rinteillä
3. **Durazzano**: viinitarhoja ja kukkulakylä, jonka läpi kulkee kapea
   mutkainen mukulakivikuja ja kellotorni

**Egypt** (teema `desert`)
1. **Bawiti**: dyynit, kaktukset ja kolme keidasta
2. **Giza**: jyrkät rinteet ja isot dyynit, Gizan pyramidit taustalla
3. **Ghamrin**: Niilin suiston pellot, kanavat, taatelipalmut ja egyptiläiset
   talot, lopuksi hiekka-aavikolle

Radat on lueteltu tiedostossa `js/tracks.js` (reitti, maasto, teema) ja autot
tiedostossa `js/cars.js` (vetotapa, teho, pito, massa ja ulkonäkö). Autot
käyttävät `car.js`:n `CAR_CONFIG`-arvoja pohjana. Autojen mallit ovat vielä
placeholdereita.

Teemat (`js/themes.js`) määräävät taivaan, valaistuksen, maaston värit, tien
pinnan, pölyn värit ja maisemaelementit.

## Ajanotto

Ajanotto käynnistyy, kun auto ylittää lähtöviivan, ja pysähtyy maaliviivalla.
Paras aika tallentuu selaimeen rata- ja autokohtaisesti: jos reittiä
muutetaan, ennätys alkaa alusta. Mutkia ei voi oikaista maaston kautta, sillä eteneminen
lasketaan vain, kun auto pysyy tien lähellä.

## Tien reitin muokkaus

Ratojen reitit ovat tiedostoissa `js/roadPath*.js` (katso tiedostolista alla):
lista `[x, z]`-pisteitä, joiden kautta
tie kulkee pehmeänä käyränä ensimmäisestä viimeiseen (tai lenkkinä, jos
`closed: true`). Samassa tiedostossa ovat lähtö- ja maaliviivan paikat. Siirrä, lisää tai poista
pisteitä ja päivitä sivu. Maasto muotoutuu tien mukaan automaattisesti
(leikkaukset ja penkereet), ja puut väistävät tietä. Samassa tiedostossa voi
säätää tien leveyttä, luiskien leveyttä, tasoitusta ja suurinta jyrkkyyttä.
Paina pelissä **M** nähdäksesi kartan, jossa pisteiden numerot näkyvät.

## Tiedostot

- `index.html`: sivu ja kirjastojen importmap
- `style.css`: HUD, valikko ja latausruutu
- `js/main.js`: käynnistys, pelisilmukka, valikon ja ajon vaihto
- `js/session.js`: yksi ajokerta (näkymä, fysiikka, rata, auto), rakennus ja purku
- `js/menu.js`: kaksiosainen päävalikko (rata, sitten auto)
- `js/tracks.js`, `js/cars.js`: valikon radat ja autot
- **Ratojen reitit (muokattavat):** `js/roadPath.js` (Harjun kierre),
  `roadPath_paijala.js`, `roadPath_ouninpohja.js`, `roadPath2.js` (Torrevecchia),
  `roadPath_tricarico.js`, `roadPath_durazzano.js`, `roadPath3.js` (Bawiti),
  `roadPath_giza.js`, `roadPath_ghamrin.js`
- `js/road.js`: tien keskilinja (spline) ja korkeusprofiili
- `js/heightmap.js`: luonnollinen maasto ja tien muotoilu maastoon, etäisyyskenttä
- `js/terrain.js`: maaston grafiikka ja törmäysmuoto
- `js/roadMesh.js`: soratien pinta
- `js/themes.js`: ratojen teemat (taivas, valot, värit, maisema)
- `js/scenery.js`: metsäteeman puut ja kivet
- `js/sceneryFinland.js`: hakkuuaukeat, pellot, paalit ja punaiset talot
- `js/sceneryTuscany.js`: Italian maisema (pellot, viinitarhat, talot, torni, puut, kylä)
- `js/sceneryDesert.js`: aavikko (keitaat, palmut, majat, kaktukset, pyramidit, suiston pellot ja talot)
- `js/sceneryKit.js`: maisemien yhteiset apufunktiot
- `js/car.js`: auton malli, jousitus ja ajologiikka; säädöt `CAR_CONFIG`-oliossa
- `js/dust.js`: pöly ja roiskeet renkaista; säädöt `DUST_CONFIG`-oliossa
- `js/stage.js`: lähtö- ja maaliportit, ajanotto ja ennätys
- `js/camera.js`: perässä seuraava kamera
- `js/mapView.js`: karttanäkymä
- `js/input.js`: näppäimistö
- `js/noise.js`: kohinafunktiot
