// Päävalikko kahdessa vaiheessa: 1) rata maittain, 2) auto. HTML-elementit canvaksen päällä.
// Näppäimet: nuolet valitsevat, Enter = seuraava / aja, Esc = takaisin / jatka ajoa.

import { TRACKS, COUNTRIES } from './tracks.js';
import { CARS } from './cars.js';
import { buildRoad } from './road.js';
import { routeKey, loadBest, formatTime } from './stage.js';

const SAVE_KEY = 'autopeli-valinta';
const DRIVE_SHORT = { 'Front-wheel drive': 'FWD', 'Rear-wheel drive': 'RWD', 'All-wheel drive': 'AWD' };
const STAT_NAMES = { power: 'Power', grip: 'Grip', agility: 'Agility' };

/** Pieni SVG-kuva reitin muodosta. */
function routeSvg(points) {
  const xs = points.map((p) => p[0]);
  const zs = points.map((p) => p[1]);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minZ = Math.min(...zs), maxZ = Math.max(...zs);
  const size = Math.max(maxX - minX, maxZ - minZ) || 1;
  const pad = 10;
  const sx = (x) => pad + ((x - minX) / size) * (100 - 2 * pad) + ((size - (maxX - minX)) / size) * (50 - pad);
  const sz = (z) => pad + ((z - minZ) / size) * (100 - 2 * pad) + ((size - (maxZ - minZ)) / size) * (50 - pad);
  const pts = points.map(([x, z]) => `${sx(x).toFixed(1)},${sz(z).toFixed(1)}`).join(' ');
  const [x0, z0] = points[0];
  const [x1, z1] = points[points.length - 1];
  return `<svg viewBox="0 0 100 100" aria-hidden="true">
    <polyline points="${pts}" fill="none" stroke="rgba(0,0,0,.35)" stroke-width="7" stroke-linejoin="round" stroke-linecap="round"/>
    <polyline points="${pts}" fill="none" stroke="#f3e6c4" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/>
    <circle cx="${sx(x0)}" cy="${sz(z0)}" r="4.5" fill="#2fbf5a" stroke="#fff" stroke-width="1.5"/>
    <circle cx="${sx(x1)}" cy="${sz(z1)}" r="4.5" fill="#e0343e" stroke="#fff" stroke-width="1.5"/>
  </svg>`;
}

export class Menu {
  constructor({ onStart, onResume }) {
    this.onStart = onStart;
    this.onResume = onResume;
    this.root = document.getElementById('menu');
    this.stepStage = document.getElementById('step-stage');
    this.stepCar = document.getElementById('step-car');
    this.stepLabel = document.getElementById('menu-step-label');
    this.keysEl = document.getElementById('menu-keys');
    this.countryWrap = document.getElementById('country-rows');
    this.carWrap = document.getElementById('car-cards');
    this.chip = document.getElementById('stage-chip');
    this.nextBtn = document.getElementById('menu-next');
    this.backBtn = document.getElementById('menu-back');
    this.resumeBtn = document.getElementById('menu-resume');
    this.isOpen = false;
    this.step = 'stage';
    this.current = null;     // käynnissä olevan session valinnat { track, car }
    this.canResume = false;

    // Tallennettu valinta (oletuksena ensimmäinen rata ja WRC-auto)
    this.track = 0;
    this.car = Math.max(0, CARS.findIndex((c) => c.id === 'wrc'));
    try {
      const saved = JSON.parse(localStorage.getItem(SAVE_KEY));
      const t = TRACKS.findIndex((x) => x.id === saved?.track);
      const c = CARS.findIndex((x) => x.id === saved?.car);
      if (t >= 0) this.track = t;
      if (c >= 0) this.car = c;
    } catch { /* ei tallennettua valintaa */ }

    // Ratojen pituudet ja ennätysavaimet (korkeuksia ei tarvita)
    this.trackRoads = TRACKS.map((t) => buildRoad(t.road, () => 0));
    this.rows = COUNTRIES.map((c) => TRACKS.map((t, i) => (t.country === c ? i : -1)).filter((i) => i >= 0));

    this.buildStageCards();
    this.buildCarCards();
    this.nextBtn.addEventListener('click', () => (this.step === 'stage' ? this.goCar() : this.start()));
    this.backBtn.addEventListener('click', () => this.goStage());
    this.resumeBtn.addEventListener('click', () => this.resume());
    addEventListener('keydown', (e) => this.onKey(e), true);
    this.update();
  }

  bestOnTrack(i, carIdx) {
    return loadBest(routeKey(this.trackRoads[i], CARS[carIdx].id));
  }

  /** Paras aika radalla millä tahansa autolla: [aika, auton nimi] tai null. */
  bestAnyCar(i) {
    let best = null;
    CARS.forEach((c, ci) => {
      const t = this.bestOnTrack(i, ci);
      if (t && (!best || t < best[0])) best = [t, c.name];
    });
    return best;
  }

  stageLength(i) {
    const r = this.trackRoads[i];
    return Math.round(r.finishAt - r.startAt);
  }

  buildStageCards() {
    this.trackCards = [];
    this.rowEls = COUNTRIES.map((country, ri) => {
      const row = document.createElement('div');
      row.className = 'country-row';
      row.innerHTML = `<h2><i class="flag flag-${country.toLowerCase()}"></i>${country}</h2><div class="cards stage-cards"></div>`;
      const wrap = row.querySelector('.cards');
      this.rows[ri].forEach((i, k) => {
        const t = TRACKS[i];
        const card = document.createElement('button');
        card.type = 'button';
        card.className = 'card';
        card.innerHTML = `
          <div class="thumb" style="--c:${t.color}">${routeSvg(t.road.points)}<span class="thumb-num">${k + 1}</span></div>
          <div class="card-body">
            <div class="card-name">${t.name}</div>
            <div class="card-desc">${t.description}</div>
            <div class="card-meta"><span>${this.stageLength(i)} m</span><span class="best"></span></div>
          </div>`;
        card.addEventListener('click', () => { this.track = i; this.update(); });
        card.addEventListener('dblclick', () => { this.track = i; this.goCar(); });
        wrap.appendChild(card);
        this.trackCards[i] = card;
      });
      this.countryWrap.appendChild(row);
      return row;
    });
  }

  buildCarCards() {
    this.carCards = CARS.map((c, i) => {
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'card';
      const bars = Object.entries(c.stats).map(([k, v]) => `
        <div class="stat"><span>${STAT_NAMES[k] ?? k}</span><i style="--v:${v}"></i></div>`).join('');
      card.innerHTML = `
        <div class="thumb car-thumb" style="--c:${c.color}">
          <div class="car-block"><b></b><em></em><em class="rear"></em></div>
          <span class="thumb-num">${DRIVE_SHORT[c.drive] ?? ''}</span>
        </div>
        <div class="card-body">
          <div class="card-name">${c.name}</div>
          <div class="card-desc">${c.drive} · ${c.description}</div>
          <div class="stats">${bars}</div>
          <div class="card-meta car-best"><span>Best on this stage</span><span class="best"></span></div>
        </div>`;
      card.addEventListener('click', () => { this.car = i; this.update(); });
      card.addEventListener('dblclick', () => { this.car = i; this.start(); });
      this.carWrap.appendChild(card);
      return card;
    });
  }

  /** Päivittää valinnat, ennätykset, vaiheen ja napit. */
  update() {
    const onStage = this.step === 'stage';
    this.stepStage.hidden = !onStage;
    this.stepCar.hidden = onStage;
    this.stepLabel.textContent = onStage ? 'Step 1 of 2 · Choose a stage' : 'Step 2 of 2 · Choose a car';

    TRACKS.forEach((t, i) => {
      const card = this.trackCards[i];
      card.classList.toggle('selected', i === this.track);
      const best = this.bestAnyCar(i);
      card.querySelector('.best').textContent = best ? `Best ${formatTime(best[0])}` : 'No time yet';
    });
    if (onStage && this.isOpen) this.trackCards[this.track].scrollIntoView({ block: 'nearest' });
    const activeRow = COUNTRIES.indexOf(TRACKS[this.track].country);
    this.rowEls.forEach((r, i) => r.classList.toggle('active', i === activeRow));

    this.carCards.forEach((c, i) => {
      c.classList.toggle('selected', i === this.car);
      const best = this.bestOnTrack(this.track, i);
      c.querySelector('.best').textContent = best ? formatTime(best) : '–';
    });

    const t = TRACKS[this.track];
    this.chip.innerHTML = `<div class="chip-thumb" style="--c:${t.color}">${routeSvg(t.road.points)}</div>
      <div><b>${t.name}</b><br><span>${t.country} · ${this.stageLength(this.track)} m · ${t.description}</span></div>`;

    this.nextBtn.innerHTML = onStage ? 'Next &rarr;' : 'Race!';
    this.backBtn.hidden = onStage;
    this.resumeBtn.hidden = !(onStage && this.canResume);
    this.keysEl.innerHTML = onStage
      ? '<b>←</b><b>→</b><b>↑</b><b>↓</b> select · <b>Enter</b> next' + (this.canResume ? ' · <b>Esc</b> resume' : '')
      : '<b>←</b><b>→</b> select · <b>Enter</b> race · <b>Esc</b> back';

    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({ track: TRACKS[this.track].id, car: CARS[this.car].id }));
    } catch { /* ei tallennusta */ }
  }

  /** Avaa valikon (aina ratavalinnasta). current = käynnissä olevan session valinnat. */
  open({ current = null, canResume = false } = {}) {
    this.isOpen = true;
    this.current = current;
    this.canResume = canResume;
    if (current) { this.track = current.track; this.car = current.car; }
    this.step = 'stage';
    this.root.hidden = false;
    document.body.classList.add('menu-open');
    this.update();
    (this.canResume ? this.resumeBtn : this.nextBtn).focus({ preventScroll: true });
  }

  close() {
    this.isOpen = false;
    this.root.hidden = true;
    document.body.classList.remove('menu-open');
    document.activeElement?.blur();
  }

  goCar() {
    this.step = 'car';
    this.update();
    this.nextBtn.focus({ preventScroll: true });
  }

  goStage() {
    this.step = 'stage';
    this.update();
    this.nextBtn.focus({ preventScroll: true });
  }

  start() {
    if (this.isOpen) this.onStart(this.track, this.car);
  }

  resume() {
    if (this.isOpen && this.canResume) this.onResume();
  }

  /** Siirtää ratavalintaa ruudukossa: dx = rivin sisällä, dy = maiden välillä. */
  moveTrack(dx, dy) {
    let ri = this.rows.findIndex((r) => r.includes(this.track));
    let k = this.rows[ri].indexOf(this.track);
    if (dy) {
      ri = (ri + dy + this.rows.length) % this.rows.length;
      k = Math.min(k, this.rows[ri].length - 1);
    }
    if (dx) k = (k + dx + this.rows[ri].length) % this.rows[ri].length;
    this.track = this.rows[ri][k];
  }

  onKey(e) {
    if (!this.isOpen || e.repeat) return;
    const onStage = this.step === 'stage';
    switch (e.code) {
      case 'ArrowLeft': case 'KeyA':
        if (onStage) this.moveTrack(-1, 0); else this.car = (this.car - 1 + CARS.length) % CARS.length;
        break;
      case 'ArrowRight': case 'KeyD':
        if (onStage) this.moveTrack(1, 0); else this.car = (this.car + 1) % CARS.length;
        break;
      case 'ArrowUp': case 'KeyW':
        if (onStage) this.moveTrack(0, -1);
        break;
      case 'ArrowDown': case 'KeyS':
        if (onStage) this.moveTrack(0, 1);
        break;
      case 'Enter': case 'NumpadEnter':
        e.preventDefault();
        if (onStage) this.goCar(); else this.start();
        return;
      case 'Escape': case 'Backspace':
        e.preventDefault();
        if (onStage) this.resume(); else this.goStage();
        return;
      default:
        return;
    }
    e.preventDefault();
    this.update();
  }
}
